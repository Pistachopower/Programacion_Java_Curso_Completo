/*
una funcion para que se le pase un entero y devuelva el numero de divisores primos que tiene (cuantos)

Por ejemplo 10
 */
package Ejercicios_Recursividad;

public class Divisores_Primos_Recursividad {

    public static void main(String[] args) {
        System.out.println("Divisores de 10: " +  + numDivisoresPrimos(10));
        
        
    }

    //esta funcion controla que num pase a false si encuentra num tenga otro divisor aparte de si mismo y de 1 
    static boolean esPrimo(int num) {
        boolean primo = true;
        
        //comienza desde 2 porque se entiende que 2 el primer primo es 2 
        int i_esPrimo = 2;

        if (num == 1) {
            primo = false;
        } else {
            while (i_esPrimo < num && primo == true) {
                if (num % i_esPrimo == 0) {
                    primo = false;
                }
                i_esPrimo++;
            }
        }
        return (primo);
    }

    static int numDivisoresPrimos(int num) {
        int cont = 0;

        for (int i_numDivisoresPrimos = 2; i_numDivisoresPrimos <= num; i_numDivisoresPrimos++) {
            //al obtener un numero diferente de 0 no comprueba la otra condicion de la funcion y pasa al siguiente
            if (num % i_numDivisoresPrimos == 0 && esPrimo(i_numDivisoresPrimos)) {
                cont++;
            }
        }
        return (cont);
    }

}
