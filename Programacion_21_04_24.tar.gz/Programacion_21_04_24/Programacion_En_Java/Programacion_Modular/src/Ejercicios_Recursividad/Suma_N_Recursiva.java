/*
sumar los numeros naturales hasta N (se lo damos nosotros) de forma recursiva

Puntos a entender 
Recursividad: una función que se llama a si misma.

Caso base: es la condicion que debe darse para que se acabe la recursividad. Por ejemplo, 
que N llegue a 1.

N=9
Paso 1
                               <-- comienza de izquierda a derecha
 1      2       3       4       5       6       7       8       9
 1     2-1     3-1     4-1     5-1     6-1     7-1     8-1    = 9-1


Paso 2

    --> regresa de izquierda a derecha  
     3    6     10      15      21      28      36     45

     ^    ^      ^       ^       ^       ^       ^      ^
1+2=3|3+3=6|6+4=10|10+5=15|15+6=21|21+7=28|28+8=36|36+9=45
1 -- 2 -- 3 -- 4 -- 5 --      6 --    7 --    8 --    9

 */
package Ejercicios_Recursividad;


public class Suma_N_Recursiva {
    public static void main(String[] args) {
        int n = 8;
        
        System.out.println(suma_N(n));

    }

    static int suma_N(int n) { //prototipo       la funcion completa: se llama definicion de la funcion
        int suma;
        
        //8,7,6,5,4,3,2,1
        if (n == 1) {
            return 1;
            
        } else {
            //1+2= 3+3= 6+4= 10+5= 15+6= 21+7= 28+8= 36
            suma= n + (suma_N(n -1)); //8-1= 7-1= 6-1= 5-1= 4-1= 3-1= 2-1= 1
        }
        
        return suma;

    }
}
