package Ejercicios_Recursividad;

import java.util.Scanner;

/*Crear un programa que pida si quiere calcular el área o volumen 
de un cilindro

        System.out.println("1-calcular area / 2-calcular volumen: ");
        opcion = teclado.nextInt();

        if (opcion == 1) {

        } else {

        }

 */
public class Hoja_Libre {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        int opcion;
         double radio, altura;

        System.out.println("1-calcular area / 2-calcular volumen: ");
        opcion = teclado.nextInt();

        if (opcion == 1) {
            
            System.out.println("radio: ");
            radio= teclado.nextDouble();
            
            System.out.println("altura: ");
            altura= teclado.nextDouble();
            
            System.out.println(Calcular_Area(radio, altura));

        } else {
            System.out.println("radio: ");
            radio= teclado.nextDouble();
            
            System.out.println("altura: ");
            altura= teclado.nextDouble();
            
            System.out.println(Calcular_Volumen(radio, altura));

        }

     

        
        

    }

    //funciones que calcular el area o volumen cilindro
    //prototipo de area
    static double Calcular_Area(double radio, double altura) {
        double area;

        area = 2 * Math.PI * radio * (radio + altura);

        return (area);
    }

    static double Calcular_Volumen(double radio, double altura) {
        double volumen;

        volumen = Math.PI * Math.pow(radio, 2) * altura;

        return (volumen);
    }

}
