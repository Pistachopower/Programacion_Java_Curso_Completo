/*Crear un programa que pida si quiere calcular el área o volumen solicitando el radio
de un cilindro*/
package Ejercicios_Recursividad;

import java.util.Locale;
import java.util.Scanner;

public class Calcular_Area_Esfera_Recursividad_Potencia_DEBEREVISARSE {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        teclado.useLocale(Locale.US);

        double radio;
        int opcion;

        System.out.println("Introduce el radio de la esfera");
        radio = teclado.nextDouble();

        System.out.println("¿Que deseas calcular con estos datos? Área (1) o Volumen (2) del cilindro");
        opcion = teclado.nextInt();

        while (opcion != 1 && opcion != 2) {
            System.out.println("Debes introducir un 1 (superficie) o un 2 (volumen) para realizar la operación");
            opcion = teclado.nextInt();
        }

        elegirOpcion(opcion, radio);
    }

    static double elevado(double a, double n) {
        double resultado;
        if (n == 0) {
            resultado = 1;
        } else {
            resultado = a * elevado(a, n - 1);
        }
        return resultado;
    }

    static void elegirOpcion(int opcion, double radio) {

        if (opcion == 1) { //
            System.out.println("La superficie de la esfera es " + 4 * Math.PI * elevado(radio, 2));
        } else {
            System.out.println("El volumen de la esfera es " + ((4 * Math.PI) / 3) * elevado(radio, 3));
        }
    }
}
