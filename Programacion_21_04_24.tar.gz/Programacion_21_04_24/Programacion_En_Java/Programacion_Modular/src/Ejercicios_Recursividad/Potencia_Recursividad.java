/*
No es trabajado en clase, solo es una funcion usada en el ejercicio de calcular area esfera 

Potencia

Base^exponente 

Ejemplo:
2³= (2*2= 4) * 2= 8

Caso base


 */
package Ejercicios_Recursividad;

public class Potencia_Recursividad {

    public static void main(String[] args) {
        int base=2;
        int exponente=3;
        
        System.out.println(Elevado(base, exponente));
    }

    static double Elevado(double a, double n) {
        double resultado;
        if (n == 0) {
            resultado = 1;
        } else {
            resultado = a * Elevado(a, n - 1);
        }
        return resultado;
    }
}
