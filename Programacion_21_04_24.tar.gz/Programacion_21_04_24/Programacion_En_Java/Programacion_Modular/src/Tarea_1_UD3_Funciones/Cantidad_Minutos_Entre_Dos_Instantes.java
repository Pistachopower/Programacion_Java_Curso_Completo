/*
Ejercicio 1:
Diseña una función a la que se le pasan las horas y minutos de dos instantes de tiempo y devuelve la
cantidad de minutos que existen de diferencia entre los dos instantes.

Diseña una segunda función que calcule e imprima el número de segundos que hay para cada
instante de tiempo.

Desde la función principal se solicitará al usuario los datos de horas y minutos y se imprimirá el
resultado de la diferencia de minutos.

    Formula pasar las horas y minutos a minutos 
tiempo_1= primer_Periodo_H * 60 + primer_Periodo_M
tiempo_2= segundo_Periodo_H * 60 + segundo_Periodo_M

final_Horas_Minutos_A_Minutos= tiempo_1 - tiempo_2

    Formula pasar las horas y minutos a segundos
tiempo_1= primer_Periodo_H * 3600 + primer_Periodo_M * 60
tiempo_2= segundo_Periodo_H * 3600 + segundo_Periodo_M * 60

final_Horas_Minutos_A_Minutos= tiempo_1 - tiempo_2


 */
package Tarea_1_UD3_Funciones;

import java.util.Scanner;

public class Cantidad_Minutos_Entre_Dos_Instantes {

    public static void main(String[] args) {
        System.out.println("Hora 1.");
        System.out.println("Hora?");
        int hora1 = new Scanner(System.in).nextInt();
        System.out.println("Minutos?");
        int minutos1 = new Scanner(System.in).nextInt();
        System.out.println("Hora 2.");
        System.out.println("Hora?");
        int hora2 = new Scanner(System.in).nextInt();
        System.out.println("Minutos?");
        int minutos2 = new Scanner(System.in).nextInt();

        int minutos = diferenciaMin(hora1, minutos1, hora2, minutos2);
        System.out.println("Minutos de diferencia: " + minutos);

        System.out.println("Los segundos de la hora 1 son:");
        numeroSegundos(hora1, minutos1);
        System.out.println("Los segundos de la hora 2 son:");
        numeroSegundos(hora2, minutos2);
    }

    static int diferenciaMin(int hora1, int minutos1, int hora2, int minutos2) {
        int diferencia = (hora2 * 60 + minutos2) - (hora1 * 60 + minutos1);
        if (diferencia < 0) {
            diferencia *= -1;
        }
        return diferencia;
    }

    static void numeroSegundos(int hora, int minutos) {
        System.out.println(hora * 3600 + minutos * 60);
    }
}
