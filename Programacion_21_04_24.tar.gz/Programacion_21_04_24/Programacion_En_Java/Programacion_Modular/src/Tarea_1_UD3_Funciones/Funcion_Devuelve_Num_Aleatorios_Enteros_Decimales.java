/*
Ejercicio 2:
Crea una función que muestre por consola una serie de números aleatorios enteros. Los parámetros
de la función serán: la cantidad de números aleatorios que se mostrarán y los valores mínimo y
máximo que éstos pueden tomar.

Sobrecarga la función anterior para que el único parámetro sea la cantidad de números aleatorios
que se muestran por consola. En este caso, los números aleatorios serán reales y estarán
comprendidos entre 0 y 1.

En la función principal se solicitará al usuario los datos necesarios (cantidad de números a mostrar y
valores máximo y mínimo).
 */
package Tarea_1_UD3_Funciones;

import java.util.Scanner;

public class Funcion_Devuelve_Num_Aleatorios_Enteros_Decimales {

    public static void main(String[] args) {
        System.out.println("5 números aleatorios entre 10 y 20: ");
        numerosAleatorios(5, 10, 20);
        System.out.println("7 números aleatorios entre 0 y 1: ");
        numerosAleatorios(7);
    }

    static void numerosAleatorios(int cuantos, int min, int max) {
        for (int i = 1; i <= cuantos; i++) {
             int aleatorio = (int) (Math.random() * (max - min + 1) + min); 
            System.out.print(aleatorio + "  ");
        }
        System.out.println("");
    }

    static void numerosAleatorios(int cuantos) {
        for (int i = 1; i <= cuantos; i++) {
            double n = Math.random();
            System.out.print(n + "  ");
        }
        System.out.println("");
    }

}
