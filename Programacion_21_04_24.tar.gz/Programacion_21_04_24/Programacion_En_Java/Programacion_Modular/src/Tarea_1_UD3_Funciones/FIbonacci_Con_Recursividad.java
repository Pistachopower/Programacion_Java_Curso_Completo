/*
Ejercicio 3:
Diseñar una función recursiva que calcule el enésimo término de la serie de Fibonacci. En esta
serie, el enésimo valor se calcula sumando los dos valores anteriores de la serie. 



Es decir:
fibonacci(n) = fibonacci(n-1) + fibonacci(n-2)
fibonacci(1) = 1
fibonacci(2) = 1
En la función principal, se solicitará el valor de n y se mostrará el resultado.

//IMPORTANTE para obtener un numero, suma los dos números anteriores. 
//Por ejemplo, si introducimos un 3, la función nos devuelve el 2.


 */
package Tarea_1_UD3_Funciones;

import java.util.Scanner;

public class FIbonacci_Con_Recursividad {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num, resultado;

        System.out.println("Vamos a calcular fibonacci(n)");
        System.out.print("Introduzca n (se recomienda n<40): ");
        num = sc.nextInt();

        resultado = fibo(num);
        System.out.println("\nfibonacci(" + num + ") = " + resultado);

    }

    static int fibo(int num) {
        int res;

        if (num == 1 || num == 2) {
            res = 1;
        } else {
            res = fibo(num - 1) + fibo(num - 2);

        }

        return (res);
    }

}
