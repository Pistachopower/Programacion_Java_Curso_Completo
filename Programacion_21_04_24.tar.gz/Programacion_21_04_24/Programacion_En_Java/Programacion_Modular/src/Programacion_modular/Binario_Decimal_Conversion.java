/*
realizar un programa que coloque un numero binario y lo 
pase a decimal

Solucion del problema
numero= 1010
        0123 --> posiciones

Para convertir este número binario a decimal, vamos a multiplicar cada dígito por una potencia de 2, 
donde la potencia es igual a la posición del dígito. Las posiciones de hacen al contrario
Paso 1:
1 * 2^0 = 1 [2⁰=1 (es por convension)]
0 * 2^1 = 0
1 * 2^2 = 4
0 * 2^3 = 0

Paso 2:
A continuación, sumamos los resultados de todas las multiplicaciones:
1 + 0 + 4 + 0 = 5

Por lo tanto, el número binario 1010 es equivalente al número decimal 10.
        
 */
package Programacion_modular;

public class Binario_Decimal_Conversion {

    public static void main(String[] args) {
        int valor_Binario = 1010;
        
        //llamas a la funcion y devuelve el resultado
        System.out.println("El binario " +  valor_Binario + " es " + (Binario_Decimal(valor_Binario)));

    }

    public static int Binario_Decimal(int valor_Binario) {
        long binario = valor_Binario; //variable para controlar que cuando se descomponga el valor termine
        
        //Las posiciones de hacen al contrario
        int entero = 0;
        int n = 0; //
        while (binario > 0) {
            long digito = binario % 10; //toma cada valor de derecha a izquiera segun la descomposicion del numero
            entero= (int) ((int) entero + digito * Math.pow(2, n)); //aplicamos la formula y guardamos en valor decimal actual
            binario = binario / 10; //funciona para descomponer binario y actualizar el valor de binario tomando solo el valor entero
            n++;
        }

        return entero;
    }

}
