/*
Escribe una función a la que se pase como parámetros de entrada una cantidad de dias, horas y minutos. La función 
calcularà y devolverá el número de segundos que existen en los datos de entrada.
 */
package Programacion_modular;

public class Num_Segundos_Que_Existe_Dias_Horas_Minutos {
    public static void main(String[] args) {
        
        System.out.println(convertirASegundos(1, 4, 35)); //segundos
        
    }
    
    public static int convertirASegundos(int dias, int horas, int minutos) {
    // Convertir días a segundos
    int segundosDias = dias * 24 * 60 * 60;

    // Convertir horas a segundos
    int segundosHoras = horas * 60 * 60;

    // Convertir minutos a segundos
    int segundosMinutos = minutos * 60;

    // Sumar todos los segundos
    int totalSegundos = segundosDias + segundosHoras + segundosMinutos;

    // Devolver el total de segundos
    return totalSegundos;
}
}
