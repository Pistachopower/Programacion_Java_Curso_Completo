/*
Sobrecarga:funciones que tienen el mismo nombre pero 
tienen diferentes parametros de entrada tipos de datos diferentes o nombre 
de variables diferentes. 

 */
package Programacion_modular;

public class teoria_Sobrecarga {
    public static void main(String[] args) {
        //System.out.print
    }
}
