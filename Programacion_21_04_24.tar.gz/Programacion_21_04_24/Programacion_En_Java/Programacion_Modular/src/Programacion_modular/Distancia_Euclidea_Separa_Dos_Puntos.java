/*
Implementa la función 

static double distancia (double x1, double yi, double x2, double y2) que calcula y devuelve la 
distancia euclidea que separa los puntos (x1, y1) y (x2, y2). La fórmula para calcular esta distancia es:

distancia=√(x1-x2)Potencia 2 +(y1-y2) potencia 2

Esta función toma las coordenadas de dos puntos como parámetros, calcula la diferencia en las coordenadas x e y, 
eleva cada diferencia al cuadrado, suma los cuadrados y finalmente devuelve la raíz cuadrada del resultado, que 
es la distancia euclidiana entre los dos puntos. 

 */
package Programacion_modular;

public class Distancia_Euclidea_Separa_Dos_Puntos {
    public static void main(String[] args) {
        System.out.println(distancia(3, 5, 4, 5));
    }
    
    public static double distancia(double x1, double y1, double x2, double y2) {
    double dx = x2 - x1;
    double dy = y2 - y1;
    return Math.sqrt(dx * dx + dy * dy);
}

}
