/*
Calculadora (funciones) (12/12)

Diseñar la función calculadora(), a la que se le pasan dos números reales (operandos) y qué 
operación se desea realizar con ellos. Las operaciones disponibles son: sumar, restar, multiplicar 
y dividir. Éstas se especifican con un número (del 1 al 4, respectivamente). La función devolverá 
el resultado de la operación mediante un número real.
 */
package Programacion_modular;

public class Calculadora_Funciones {

    public static void main(String[] args) {
        double a, b;
        a = 2;
        b = 1;
        
        System.out.println(menu_Opciones(5,1, 1));

        //System.out.println(suma(1, 1,1));
    }

    static double menu_Opciones(int opcion, int a, int b) {
        double resultado=0;
        switch (opcion) {
            case 1:
                resultado= suma(a, b);
                break;
            case 2:
                resultado= resta(a, b);
                break;
            case 3:
                resultado= multiplicacion(a, b);
                break;
            case 4:
                resultado= division(a, b);
                break;
            default:
                System.out.println("El valor no es correcto. ");
        }
        return resultado;
    }
    
    //suma
    static double suma(int a, int b) {
        return (a + b);
    }
    static double resta(int a, int b) {
        return (a - b);
    }
    static double multiplicacion(int a, int b) {
        return (a * b);
    }
    static double division(int a, int b) {
        return (a / b);
    }
    
}
