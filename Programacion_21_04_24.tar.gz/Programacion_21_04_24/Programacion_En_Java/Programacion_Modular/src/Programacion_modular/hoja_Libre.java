package Programacion_modular;

import java.util.Scanner;

/*
Calculadora (funciones) (12/12)

Diseñar la función calculadora(), a la que se le pasan dos números reales (operandos) y qué 
operación se desea realizar con ellos. Las operaciones disponibles son: sumar, restar, multiplicar 
y dividir. Éstas se especifican con un número (del 1 al 4, respectivamente). La función devolverá 
el resultado de la operación mediante un número real.
 */
public class hoja_Libre {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int opcion;
        
        System.out.println("1 suma, 2 resta, 3 multiplicar, 4 dividir:   ");
        opcion= teclado.nextInt();
        
        //llamamos a la funcion
        Calculadora(opcion);
        
        

    }

    //funciones que hacen las operaciones aritmeticas
    static int Suma(int a, int b) {
        return a + b;
    }
    static int Resta(int a, int b) {
        return a - b;
    }
    static int Multiplicacion(int a, int b) {
        return a * b;
    }
    static int Division(int a, int b) {
        return a / b;
    }

    
    //creamos una funcion que nos permite seleccionar la operacion aritmetica
    static void Calculadora(int opcion) {
        
        Scanner teclado = new Scanner(System.in);
        int a, b, respuesta;
        
        //hacemos un switch 
        switch (opcion) {
            case 1:
                
                
                //pedimos los valores para hacer la operacion
                
                System.out.println("Introduce el valor 1: ");
                a= teclado.nextInt();
                
                System.out.println("Introduce el valor 2: ");
                b= teclado.nextInt();
                
                //llamamos a la funcion y guardamos el valor
                respuesta= Suma(a, b);
                
                //mostramos 
                System.out.println("La suma es " +  respuesta);
                
                break;
            case 2:
                
                
                //pedimos los valores para hacer la operacion
                
                System.out.println("Introduce el valor 1: ");
                a= teclado.nextInt();
                
                System.out.println("Introduce el valor 2: ");
                b= teclado.nextInt();
                
                //llamamos a la funcion y guardamos el valor
                respuesta= Resta(a, b);
                
                //mostramos 
                System.out.println("La resta es " +  respuesta);
                
                break;
                
            case 3:
                
                
                //pedimos los valores para hacer la operacion
                
                System.out.println("Introduce el valor 1: ");
                a= teclado.nextInt();
                
                System.out.println("Introduce el valor 2: ");
                b= teclado.nextInt();
                
                //llamamos a la funcion y guardamos el valor
                respuesta= Multiplicacion(a, b);
                
                //mostramos 
                System.out.println("La multiplicacion es " +  respuesta);
                
                break;
                
            case 4:
                
                
                //pedimos los valores para hacer la operacion
                
                System.out.println("Introduce el valor 1: ");
                a= teclado.nextInt();
                
                System.out.println("Introduce el valor 2: ");
                b= teclado.nextInt();
                
                //llamamos a la funcion y guardamos el valor
                respuesta= Division(a, b);
                
                //mostramos 
                System.out.println("La division es " +  respuesta);
                
                break;
                
                
                
                
            default:
                System.out.println("El valor no es correcto. ");
        }

    }

}
