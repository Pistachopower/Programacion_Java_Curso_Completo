/*
buscar el ejercicio del maximo de dos numero y modificarlo y agregar una funcion de 
sobrecarga que devuelva el maximo de 3 numeros 
 */
package Programacion_modular;

import static Programacion_modular.Num_Max_Funcion.num_Maximo;

public class Maximo_Tres_Numeros_Sobrecarga {

    public static void main(String[] args) {
        int a, b, c;

        //a = 8;
        //b = 5;
        //otras maneras de colocar una funcion
        System.out.println("El número mayor es: " + num_Maximo(4, 7));
        System.out.println("El número mayor es: " + num_Maximo(10, 7, 100));
    }

    static int num_Maximo(int a, int b) {
        int resultado = 0;

        if (a > b) {
            resultado = a;
        }
        if (b > a) {
            resultado = b;
        }

        return resultado;

    }
    
        static int num_Maximo(int a, int b, int c) {
        int resultado = 0;

        if (a > b && b > c) {
            resultado= a;
        }
        if (a > c && c > b) {
            resultado= a;
        }
        //seguimos con b 
        if (b > c && c > a) {
            resultado= b;
        }
        if (b > a && a > c) {
            resultado= b;
        }
        //seguimos con la c
        if (c > a && a > b) {
            resultado= c;
        }
        if (c > b && b > a) {
            resultado= c;
        }

        return (resultado);
    }
}

