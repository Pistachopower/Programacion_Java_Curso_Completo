/*
funcion que recibe dos enteros y devuelve el maximo de los dos
 */
package Programacion_modular;

public class Num_Max_Funcion {

    public static void main(String[] args) {
        int a, b;

        //a = 8;
        //b = 5;
        
        //otras maneras de colocar una funcion
        System.out.println("El número mayor es: " + num_Maximo(4, 7));
    }

    static int num_Maximo(int a, int b) {
        int resultado = 0;

        if (a > b) {
            resultado = a;
        }
        if (b > a) {
            resultado = b;
        }

        return resultado;

    }
}
