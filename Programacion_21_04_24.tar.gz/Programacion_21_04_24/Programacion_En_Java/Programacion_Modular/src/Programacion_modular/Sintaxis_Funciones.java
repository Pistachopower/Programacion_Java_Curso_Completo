package Programacion_modular;

/*
    
    static tipoDato nombreFuncion(tipoDato nombreParametro) {
        cuerpo de la funcion
    
    }
 */
public class Sintaxis_Funciones {

    public static void main(String[] args) {
        //llamar o invocar a la funcion
        //tresSaludos(5);
        //con operadores aritmeticos
//        int a=1;
//        tresSaludos(a);

        //con operadores aritmeticos
        int a = 1;
        tresSaludos(3 * a);
    }

    //no devuelve nada porque tiene void
    static void tresSaludos(int veces) { //prototipo       la funcion completa: se llama definicion de la funcion
        System.out.println("Voy a saludar " + veces + "veces");
        
        for (int i = 0; i < veces; i++) {
            System.out.println("hola");
        }

    }
}
