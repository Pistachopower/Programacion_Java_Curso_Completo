package Arrays_Ejercicios;
import java.util.Scanner;

public class Array_N_Numeros_Media_Posit_Negativ_Contar_0_For_Each {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int n;

        //variable para sacar la media
        double suma_Numeros_Positivos, suma_Numeros_Negativos;
        suma_Numeros_Positivos = 0;
        suma_Numeros_Negativos = 0;

        int cantidad_Ceros = 0;

        //pedir N
        System.out.println("Introduce la longitud del array: ");
        n = teclado.nextInt();

        //definimos el array con el valor del usuario
        int num_Array[] = new int[n];

        //rellenamos el array
        for (int i = 0; i < num_Array.length; i++) {

            //reutilizamos n para guardar ahora los valores del usuario
            System.out.println("COLOCA EL VALOR: ");
            //rellenamos el valor pasado por teclado al array
            num_Array[i] = teclado.nextInt();
        }

        //sumamos los valores negativos, positivos y los ceros
        for (int numero : num_Array) {
            //verifica si n es igual a 0
            if (numero == 0) {
                cantidad_Ceros = cantidad_Ceros + 1;
            }

            //verifica si n es un numero positivo
            if (numero > 0) {
                //calcula la suma para la media de numeros positivos
                suma_Numeros_Positivos = suma_Numeros_Positivos + numero;
            }
            //
            if (numero < 0) {
                //calcula la suma para la media de numeros negativos
                suma_Numeros_Negativos = suma_Numeros_Negativos + numero;

            }
        }

        System.out.println("Cantidad de ceros: " + cantidad_Ceros);
        System.out.println("La media de números positivos es: " + (suma_Numeros_Positivos / num_Array.length));
        System.out.println("La media de números negativos es: " + (suma_Numeros_Negativos / num_Array.length));
    }
}
