package Arrays_Ejercicios;

import java.util.Arrays;

/*
Suma consecutivos (19/01)

Implementa la función: int[ ] suma(int t[ ], int numElementos), que crea y devuelve una tabla con las sumas de los numElementos 
elementos consecutivos de t. Veamos un ejemplo: sea t=[10,1,5,8,9,2]. Si los elementos de t se agrupan de 3 en 3 (numElementos=3), 
se harán las sumas:m

10+1+5=16
1+5+8=14
5+8+9=22
8+9+2=19

Realizar la inserción de cada resultado de las sumas siguiendo el procedimiento de inserción en tablas ordenadas, de forma que 
la tabla resultante quede ordenada.

Así, para el ejemplo, la función devolverá la tabla [14, 16, 19, 22].
Se deberá mostrar información de cada suma realizada y, al final, la tabla resultante.

 */
public class Suma_Consecutiva_Clase_Arrays {

    public static void main(String[] args) {
        //defino y creo array de enteros 
        int array[] = {10, 1, 5, 8, 9, 2};

        //variable que guarda el total de elementos seleccionados
        int numElementos = 3;

        //invoco a la funcion pasando las variables anteriores
       
         System.out.println(Arrays.toString( suma(array, numElementos)));

    }

    //definimos el prototipo
    static int[] suma(int t[], int numElementos) {
        //tabla final que mostrara los valores ordenada 
        int tabla_Final[] = new int[t.length - 2]; //la tabla final tendra longit de 4

        //recorro la longitud de tabla final
        for (int j = 0; j < tabla_Final.length; j++) {
            //variable indice

            //tabla que agrupa de 3 en 3 los elementos
            int temporal[] = new int[numElementos]; //por cada iteracio se reinicializa

            //pego los elementos en grupo de tres por indice de j 
            System.arraycopy(t, j, temporal, 0, numElementos);
            
             System.out.println("Valores a sumar: " + Arrays.toString(temporal));

            //variable suma para guardar el resultado de la sumas consecutivas
            int suma = 0; //por cada iteracio se reinicializa

            //sumo los elementos de temporal
            for (int i : temporal) {
                suma = suma + i;
            }

            
            //ponemos el valor de suma en la tabla final con el indice actual
              tabla_Final[j] = suma;

        }

        Arrays.sort(tabla_Final);
        return (tabla_Final);
    }


}
