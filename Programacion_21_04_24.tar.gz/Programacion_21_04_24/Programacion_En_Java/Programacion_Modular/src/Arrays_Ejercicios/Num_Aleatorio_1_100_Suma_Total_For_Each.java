
/*
CREAR UNA TABLA DE LONGITUD 10 QUE SE INICIALIZARA CON NUMEROS ALEATORIOS COMPRENDIDOS 
ENTRE 1 Y 1OO. MOSTRAR LA SUMA DE TODOS LOS NUMEROS ALEATORIOSQUE SE GUARDAN EN LA TABLA
 */
package Arrays_Ejercicios;

public class Num_Aleatorio_1_100_Suma_Total_For_Each {

    public static void main(String[] args) {
        int num_Array[] = new int[10];

        //RECORREMOS Y RELLENAMOS LOS INDICES CON LOS VALORES ALEATORIOS
        for (int i = 0; i < num_Array.length; i++) {
            int aleatorio = (int) (Math.random() * (100 - 1 + 1) + 1);

            num_Array[i] = aleatorio;

        }

 
        int suma_Aleatorios = 0;

        for (double valor : num_Array) {
            suma_Aleatorios += valor;

        }

        System.out.println(suma_Aleatorios);
    }
}
