/*
Escribe la función void desordenar (int t[]), que cambia de forma aleatoria los ele- mentos contenidos en la tabla t. 
Si la tabla estuviera ordenada, dejaria de estarlo.
 */
package Arrays_Ejercicios;

import java.util.Arrays;

public class Desordenar_Array_Aleatoria {

    public static void main(String[] args) {
        int array [] = {2,4,5,6,9};
        
        desordenar(array);
        
        System.out.println(Arrays.toString(array));
        //System.out.println(desordenar(array));
 
    }

    public static void desordenar(int[] t) {
        
        for (int i = 0; i < t.length; i++) {
            int randomIndexToSwap = (int) (Math.random() * t.length);
            int temp = t[randomIndexToSwap];
            t[randomIndexToSwap] = t[i];
            t[i] = temp;
        }
    }
}
