package Arrays_Ejercicios;

import java.util.Arrays;

public class CopiarTablasCopyOfCopyOfRange {

    public static void main(String[] args) {
        //definimos el array con los valores
        int origen[] = {3,4,5,6};
        int destino[]= {};
      
        /*
        copia_Array[]= Arrays.copyOf(array_Copiar, longitud_Array) --> copia los elementos del array indiceFinal-1

         */
        int copia[] = Arrays.copyOf(origen, origen.length); //indiceFinal-1

        /*
        pasar un array a una cadena de texto:
        Arrays.toString(array)
         */
//        System.out.println("Original: " + Arrays.toString(origen));
//        System.out.println("Copia: " + Arrays.toString(copia));

        /*
        Si quieres copiar un array y quieres obtener la longitud del array
        sin contar los índices lo puedes hacer automáticamente con
       
        Arrays.copyOf(arrayCopiar, arrayCopiar.length);
         */
//        int copia1[] = Arrays.copyOf(origen, origen.length);
//        System.out.println("Copia1: " + Arrays.toString(copia1));
//
//        //forma manual de copiar un array y agregar más elementos en los índices por defecto
//        int copia2[] = Arrays.copyOf(origen, 10);
//        System.out.println("Copia2: " + Arrays.toString(copia2));
//
//        //copiar un array desde y hasta indices específicos recuerda indiceFinal-1
//        int copiaDelRango[] = Arrays.copyOfRange(origen, 0, 3);
//        System.out.println("opiaDelRango: " + Arrays.toString(copiaDelRango));
//
//        int copyOfRange1[] = Arrays.copyOfRange(origen, 4, 7);
//        System.out.println("CopyOfRange1: " + Arrays.toString(copyOfRange1));
        
        //copiar valores de un array y pegarlos en otro
        System.out.println("Pegar los valores a otra tabla");
      //
        System.arraycopy(origen, 2, destino, destino.length-1, 1);
        System.out.println(Arrays.toString(destino));
        
        
        
        
    }
}
