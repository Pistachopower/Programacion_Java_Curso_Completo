/*
El ayuntamiento de tu localidad te ha encargado una aplicación que ayude a realizar encuestas estadisticas para conocer el 
nivel adquisitivo de los habitantes del municipio. Para ello, tendrás que preguntar el sueldo a cada persona encuestada. 
A priori, no conoces el número de encuestados. Para finalizar la entrada de datos, introduce un sueldo con valor-1

Una vez terminada la entrada de datos, muestra la siguiente información:

Todos los sueldos introducidos ordenados de forma decreciente.

El sueldo máximo y minimo.

La media de los sueldos.
 */
package Arrays_Ejercicios;

import java.util.Arrays;
import java.util.Scanner;

public class Z_Alcaldia {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] sueldos = new int[0];
        int sueldo;

        // Entrada de datos
        do {
            System.out.print("Introduce el sueldo (introduce -1 para terminar): ");
            sueldo = scanner.nextInt();

            if (sueldo != -1) {
                // Aumenta el tamaño del array en 1 y añade el nuevo sueldo
                sueldos = Arrays.copyOf(sueldos, sueldos.length + 1);
                sueldos[sueldos.length - 1] = sueldo;
            }
        } while (sueldo != -1);

        // Ordena el array de forma decreciente
        Arrays.sort(sueldos);
        int[] sueldosOrdenados = new int[sueldos.length];
        for (int i = 0; i < sueldos.length; i++) {
            sueldosOrdenados[i] = sueldos[sueldos.length - 1 - i];
        }

        // Calcula la media de los sueldos
        double suma = 0;
        for (int i : sueldos) {
            suma += i;
        }
        double media = suma / sueldos.length;

        // Muestra la información
        System.out.println("Sueldos ordenados de forma decreciente: " + Arrays.toString(sueldosOrdenados));
        System.out.println("Sueldo máximo: " + sueldosOrdenados[0]);
        System.out.println("Sueldo mínimo: " + sueldosOrdenados[sueldosOrdenados.length - 1]);
        System.out.println("Media de los sueldos: " + media);
    }
}

    

