
package Arrays_Ejercicios;

import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;

        /*Definir una funcion que tome como parametros dos tablas, la primera 
        con los 6 numeros de una apuesta de la primitiva y la segunda con los 
        6 numeros de la combinación ganadora (tiene que estar ordenada). 
        La función devolverá el numero de aciertos.*/
public class Apuesta_Primitiva_Ejemplo_BinarySearch {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner (System.in);
        sc.useLocale(Locale.US);
        
        int apuesta[] = {9, 17, 20, 64, 70, 71};
        int combinacionGanadora[] = {4, 9, 23, 50, 64, 71};
        
        System.out.println("Numero de aciertos: " + primitiva (apuesta,combinacionGanadora));
    }
    
    //Devuelve el numero de coincidencias entre los elementos de las tablas
        static int primitiva (int apuesta[], int combinacionGanadora[]) {
        int aciertos = 0;
        
            for (int i : apuesta) {//recorremos la tabla apuesta
                //aprovechamos que la tabla con la combinacion esta ordenada
                if (Arrays.binarySearch(combinacionGanadora,i) >= 0) {
                    aciertos++; //hemos acertado un numero mas
                }
            }
        return aciertos;
    }
}
