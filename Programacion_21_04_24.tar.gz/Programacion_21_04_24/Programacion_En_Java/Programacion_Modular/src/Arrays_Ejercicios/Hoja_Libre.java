package Arrays_Ejercicios;

import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;

/*
Desarrollar el juego “la cámara secreta” que consiste en abrir una cámara mediante su 
combinación secreta, que está formada por una combinación de dígitos del 1 al 5. El 
jugador especificará cuál es la longitud de la combinación; a mayor longitud, mayor 
será la dificultad del juego. La aplicación genera, de forma aleatoria, una combinación 
secreta que el usuario tendrá que acertar. En cada intento se muestra como pista, para 
cada dígito de la combinación introducido por el jugador, si es mayor, menor o igual 
que el correspondiente en la combinación secreta.
*/


public class Hoja_Libre {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Indica longitud de la camara: ");
        int l= teclado.nextInt();
        
        //creamos la tabla del juego 
        int t[]= new int[l];
        
        //creamos la tabla del jugador
        int j[]= new int[l];
        
        
        //invocamos a la funcion y guardamos la tabla final para empezar el juego
        t= rellenaT(t, l);
         //mostramos el valor j
         System.out.println(Arrays.toString(t));
        
        
        //rellenamos la tabla con los valores que digita el usuario
        for (int i = 0; i < l; i++) {
            System.out.println("Introduce el numero ");
            int v= teclado.nextInt();
            
            j[i]= v;
            
        }
        
       
        
        //comparamos los valores de cada indice y damos pistas 
        for (int i = 0; i < l; i++) {
            if (t[i] < j[i]) {
                System.out.println(j[i] + " es mayor que el valor de la tabla");
                
            } else if (t[i] > j[i]) {
                 System.out.println(j[i] + " es menor que el valor de la tabla");
            } else {
                 System.out.println(j[i] + " es igual al valor de la tabla");
            
            }
            
        }
        
        if (Arrays.equals(t, j)) {
            System.out.println("Has abierto la cámara");
        } else {
            System.out.println("Los valores no son correctos ");
        }
        
    }
    
    //creamos la funcion rellenar arrays que devuelva el array 
    static int[] rellenaT (int tabla[], int longitud) {
        //llenamos el array 
        for (int i = 0; i < longitud; i++) {
            //creamos el valor aleatorio para llenarlo
             int aleatorio = (int) (Math.random() * (5 - 1 + 1) + 1); 
             
             //lo pasamos al array por cada iteracion
             tabla[i]= aleatorio;
        }
        
        //devolvemos la tabla
        return tabla;
        
	}


}
