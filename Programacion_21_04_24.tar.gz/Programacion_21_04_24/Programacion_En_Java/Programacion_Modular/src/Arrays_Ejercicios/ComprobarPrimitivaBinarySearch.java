package Arrays_Ejercicios;

import java.util.Arrays;

public class ComprobarPrimitivaBinarySearch {

    public static void main(String[] args) {
//        Metodo BinarySearch (búsqueda dicotomica)

//Importante: debe estar ordenado (Array.sort) el array antes de usar la función. Se puede 
//usar en los If.
//Funciona con el For each.
//Sintaxis:
//Arrays.binarySearch(arraySeleccionado, valorBuscar)
//Importante: devuelve el índice que se encuentra el valorBuscar. Si valorBuscar aparece en varios indices no es eficiente. Sino existe devuelve un menos. 
//Ejemplo (PROBAR Y HACER)
        int array[] = {2, 4, 5, 6, 9};
        int busquedaB = Arrays.binarySearch(array, 5);

        //muestra el indice 2
        System.out.println(busquedaB);

        int busquedaB2 = Arrays.binarySearch(array, 3);

        //muestra un valor negativo cuando no encuentra el valor
        System.out.println(busquedaB2);

        //int indiceInsercion = ( - pos ) - 1 → 1.
        //Podemos en una búsqueda dicotómica decirle en que rango de la tabla queremos buscar,
        //seria de esta manera:
        //Static int binarySearch ( tipo t [], int desde, int hasta, clave)
        //EL HASTA LE TENEMOS QUE RESTAR 1, DESDE 1 HASTA 4, BUSCARIA DESDE 0
        //HASTA 3, NO SE INCLUYE EL HASTA
        //
        //cuando devuelve un valor negativo la funcion binarySearch lo que te devuelve es la posicion donde deberías colocar el numero en el array
        int a[] = {2, 4, 5, 6, 9};

        int pos = Arrays.binarySearch(a, 3); //da -2

        System.out.println(pos);

        int indiceInsercion = -(pos) - 1; //vale 1. Usa la ley de signos y el valor absoluto       
        System.out.println(indiceInsercion); //muestra el indice donde tienes que colocar ese valor en el array si lo quieres ordenar

    }
}
