/*
realizar una funcion que devuelva un array con un nuevo valor ordenado
 */
package Arrays_Ejercicios;

import java.util.Arrays;

public class Insercion_Ordenada_Funcion {

    public static void main(String[] args) {
        //tabla inicial
        int t[] = {1, 2, 3, 4, 6, 7, 8};

        int valor = 9;

        insercion_Ordenada(t, valor);
        
        System.out.println(Arrays.toString(insercion_Ordenada(t, valor))); //mostramos

    }

    static int[] insercion_Ordenada(int tabla1[], int valor_Agregar) {
        //nueva tabla con longitud +1 al elemento que vamos a agregar
        int copia[] = new int[tabla1.length + 1]; //{1, 2, 3, 4, 6, 7, 8,0}

        //devuelve el indice si existe el numero o el posible indice de insercion 
        int indiceInsercion = Arrays.binarySearch(tabla1, valor_Agregar);

        //si indiceInsercion >=0, el nuevo elemento (que está repetido)se inserta en
        //el lugar en que ya estaba, desplazando al original. Si por el contrario:
        if (indiceInsercion < 0) { //sino lo encuentra
            //calcula donde deberia estar
            indiceInsercion = -(indiceInsercion) - 1;

        }

        //copiamos los elementos antes del hueco 
        System.arraycopy(tabla1, 0, copia, 0, indiceInsercion); //(parametro ultimo posicion)

        //copiamos desplazados los elementos tras el hueco
        System.arraycopy(tabla1, indiceInsercion, copia, indiceInsercion + 1, tabla1.length - indiceInsercion);
        copia[indiceInsercion] = valor_Agregar; //asignamos el nuevo elemento
        tabla1 = copia; //t referencia la nueva tabla

        return (tabla1);
    }

}
