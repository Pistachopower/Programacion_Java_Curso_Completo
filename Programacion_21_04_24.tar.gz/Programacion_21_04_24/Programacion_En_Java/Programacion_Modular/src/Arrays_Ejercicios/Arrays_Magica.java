/*
Escribe un programa que solicite los elementos de una matriz de tamaño 4 x 4. La aplicación debe decidir si la matriz introducida 
corresponde a una matriz mágica, que es aquella donde la suma de los elementos de cualquier fila o de cualquier columna valen lo mismo.
 */
package Arrays_Ejercicios;

import java.util.Scanner;

public class Arrays_Magica {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Definir la matriz de tamaño 4x4
        int[][] matriz = new int[4][4];

        // Solicitar los elementos de la matriz al usuario
        System.out.println("Introduce los elementos de la matriz 4x4:");

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print("Elemento [" + (i + 1) + "][" + (j + 1) + "]: ");
                matriz[i][j] = scanner.nextInt();
            }
        }

        // Verificar si es una matriz mágica
        if (esMatrizMagica(matriz)) {
            System.out.println("¡La matriz es mágica!");
        } else {
            System.out.println("La matriz no es mágica.");
        }

        
    }
    
     // Función para verificar si la matriz es mágica
    static boolean esMatrizMagica(int[][] matriz) {
        // Calcular la suma de la primera fila para comparar
        int sumaFila = 0;
        for (int j = 0; j < 4; j++) {
            sumaFila += matriz[0][j];
        }

        // Verificar la suma de las filas
        for (int i = 1; i < 4; i++) {
            int sumaFilaActual = 0;
            for (int j = 0; j < 4; j++) {
                sumaFilaActual += matriz[i][j];
            }

            if (sumaFilaActual != sumaFila) {
                return false; // No es una matriz mágica
            }
        }

        // Verificar la suma de las columnas
        for (int j = 0; j < 4; j++) {
            int sumaColumna = 0;
            for (int i = 0; i < 4; i++) {
                sumaColumna += matriz[i][j];
            }

            if (sumaColumna != sumaFila) {
                return false; // No es una matriz mágica
            }
        }

        // Si pasa todas las verificaciones, es una matriz mágica
        return true;
    }
}
