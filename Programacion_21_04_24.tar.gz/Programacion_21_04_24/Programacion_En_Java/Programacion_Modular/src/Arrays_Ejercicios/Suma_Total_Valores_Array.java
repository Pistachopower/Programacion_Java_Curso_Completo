/*
crear tabla longitud 10 que se inicializara con numeros aleatorios comprendidos entre 1 y 100. 
Mostrar la suma de todos los numeros aleatorios que se guardan en la tabla. 

 */
package Arrays_Ejercicios;

public class Suma_Total_Valores_Array {

    public static void main(String[] args) {
        //crear tabla longitud 10 
        int num_Array[] = new int[10];

        //variable que suma los valores que dará aleatorio
        int suma_Aleatorio = 0;

        for (int i = 0; i < num_Array.length; i++) {
            //se inicializara con numeros aleatorios comprendidos entre 1 y 100. 
            int aleatorio = (int) (Math.random() * 100 + 1);

            //rellenamos array
            num_Array[i] = aleatorio;
            
            //System.out.println("Indice " + i + " , valor: " + num_Array[i]);

        }

        //sumamos los valores del array a suma_Aleatorio
        for (int i = 0; i < num_Array.length; i++) {
            suma_Aleatorio= suma_Aleatorio + num_Array[i];
            
        }

        //mostramos
        System.out.println("Suma de aleatorios: " + suma_Aleatorio);
    }
}
