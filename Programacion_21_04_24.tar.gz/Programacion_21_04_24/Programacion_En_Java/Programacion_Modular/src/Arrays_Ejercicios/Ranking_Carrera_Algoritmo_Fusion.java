/*
Diseña una aplicación para gestionar la llegada a meta de los
participantes de una carrera. Cada uno de ellos dispone de un dorsal (nº
entero) que los identifica. En la aplicación se introduce un nº de
dorsal de cada corredor cuando éste llega a la meta (introduciendo un -1
para indicar que ya han llegado a meta todos los corredores). 
A
continuación, la aplicación solicita información extra de los
corredores. En primer lugar, el usuario introducirá los dorsales de
todos los corredores menores de edad (finalizando con -1), a los que se
les premiará por su esfuerzo adelantándoles una posición en el ranking
general de la carrera, esa decir, es como si hubieran adelantado al
corredor que llevaban delante.
En segundo lugar, el usuario
introducirá los dorsales de los corredores que han dado positivo en test
antidopaje (finalizando con -1), lo que provoca su expulsión inmediata de la lista general
del ranking .
Para finalizar, el usuario introducirá los dorsales de los corredores que no han pagado su inscripción a la
carrera (finalizando con -1), lo que provoca que sean relegados a los últimos puestos del ranking.
Tras todo esto, la aplicación debe
mostrar los dorsales de los corredores que han conseguido las medallas
de oro, plata y bronce.
Crear funciones para hacer el programa más legible.


incluye el algoritmo de fusión (eliminaOrdenado) para mantener el array ordenado después de eliminar un elemento.
 */
package Arrays_Ejercicios;

import java.util.Arrays;
import java.util.Scanner;

public class Ranking_Carrera_Algoritmo_Fusion {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int ranking[];

        System.out.print("Cuántos corredores participan: ");
        int numCorredores = sc.nextInt();
        ranking = new int[numCorredores];

        System.out.println("Escriba los dorsales que van llegando a la meta:");
        for (int i = 0; i < ranking.length; i++) {
            System.out.print("Dorsal número: ");
            ranking[i] = sc.nextInt();
        }

        System.out.println(Arrays.toString(ranking));

        System.out.println("Dorsales de los menores de edad (-1 para acabar)");
        int dorsal = sc.nextInt();

        while (dorsal != -1) {
            avanza1Puesto(ranking, dorsal);
            System.out.println(Arrays.toString(ranking));
            System.out.println("Dorsales de los menores de edad (-1 para acabar)");
            dorsal = sc.nextInt();
        }

        System.out.println("Dorsales positivos en antidoping (-1=fin)");
        dorsal = sc.nextInt();
        while (dorsal != -1) {
            ranking = eliminaOrdenado(ranking, dorsal);
            System.out.println(Arrays.toString(ranking));
            System.out.println("Dorsales positivos en antidoping (-1=fin)");
            dorsal = sc.nextInt();
        }

        System.out.println("Dorsales que no han pagado (-1=fin)");
        dorsal = sc.nextInt();
        while (dorsal != -1) {
            ultimoPuesto(ranking, dorsal);
            System.out.println(Arrays.toString(ranking));
            System.out.println("Dorsales que no han pagado (-1=fin)");
            dorsal = sc.nextInt();
        }

        System.out.println("--- Medallero ---");
        if (ranking.length >= 1) {
            System.out.println("Oro: " + ranking[0]);
        }
        if (ranking.length >= 2) {
            System.out.println("Plata: " + ranking[1]);
        }
        if (ranking.length >= 2) {
            System.out.println("Bronce: " + ranking[2]);
        }

    }

    static void avanza1Puesto(int ranking[], int dorsal) {
        int posicion = busca(ranking, dorsal);

        if (posicion == -1) {
            System.out.println("Error: el dorsal " + dorsal + " no existe.");
        } else {
            if (posicion != 0) {
                int aux = ranking[posicion - 1];
                ranking[posicion - 1] = ranking[posicion];
                ranking[posicion] = aux;
            }
        }
    }

    static int busca(int t[], int clave) {
        int posicion = -1;
        int i = 0;

        while (i < t.length && t[i] != clave) {
            i++;
        }

        if (i < t.length) {
            posicion = i;
        }

        return posicion;
    }

    static int[] eliminaOrdenado(int t[], int clave) {
        int posicion = busca(t, clave);

        if (posicion == -1) {
            System.out.println("Error: el dorsal " + clave + " no existe.");
        } else {
            int[] nuevoRanking = new int[t.length - 1];
            int i = 0, j = 0;

            while (i < posicion) {
                nuevoRanking[j++] = t[i++];
            }

            i++;

            while (i < t.length) {
                nuevoRanking[j++] = t[i++];
            }

            return nuevoRanking;
        }

        return t;
    }

    static void ultimoPuesto(int ranking[], int dorsal) {
        int posicion = busca(ranking, dorsal);

        if (posicion == -1) {
            System.out.println("Error: el dorsal " + dorsal + " no existe.");
        } else {
            System.arraycopy(ranking, posicion + 1,
                    ranking, posicion, ranking.length - posicion - 1);
            ranking[ranking.length - 1] = dorsal;
        }
    }
}
