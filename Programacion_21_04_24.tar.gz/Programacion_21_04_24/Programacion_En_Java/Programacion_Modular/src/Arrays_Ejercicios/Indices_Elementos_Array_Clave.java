/*
Realiza la función: int[] buscarTodoslint t[], int clave), que crea y devuelve una tabla con todos los indices de los elementos donde 
se encuentra la clave de búsqueda. En el caso de que clave no se encuentre en la tabla t. la función devolverá una tabla vacia
 */
package Arrays_Ejercicios;

import java.util.Arrays;

public class Indices_Elementos_Array_Clave {

    public static void main(String[] args) {
        int[] t = {1, 2, 3, 4, 5, 5, 5, 6, 7, 8, 9};
        int clave = 5;
        int[] indices = buscarTodos(t, clave);
        System.out.println(Arrays.toString(indices));
    }

    public static int[] buscarTodos(int[] t, int clave) {
        int[] indicesTemp = new int[t.length];
        int count = 0;

        for (int i = 0; i < t.length; i++) {
            if (t[i] == clave) {
                indicesTemp[count++] = i;
            }
        }

        return Arrays.copyOf(indicesTemp, count);
    }
}
