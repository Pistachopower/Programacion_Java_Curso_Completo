/*
escribir la funcion int[] eliminarMayores(int t[], int valor)la funcion 
debe devolver una tabla con valores menores a valor
 */
package Arrays_Ejercicios;

import java.util.Arrays;

public class Funcion_Eliminar_Mayores_Tablas_Ejemplo_ArrayCopyOf {

    public static void main(String[] args) {
        //creamos el array desordenado
        int array[] = {9, 7, 12, 19};

        System.out.println(Arrays.toString(eliminarMayores(array, 10)));
    }

    static int[] eliminarMayores(int t[], int valor) {

        int copia[] = Arrays.copyOf(t, t.length); //hace una copia exacta 

        //para iterar
        int i = 0;

        while (i < copia.length) {
            //{9, 7, 12, 19} > 10?
            if (copia[i] > valor) {
                /*
                i=0,1,2 --> cuando está aqui, quita el 12 y duplica el 19 en donde estaba el 12
                {9, 7, 12, 19} 
                {9, 7, 19, 19} 
                 */
                copia[i] = copia[copia.length - 1]; //se resta uno para estar en el indice correcto y no salga fuera del indice

                /*
                De esta copia: {9, 7, 19, 19} con la funcion toma longitud de copia 3 - 1= 2, tomando los indices: 0,1,2
                Queda así: {9, 7, 19}
                
                Vuelve  a iterar en el mismo indice pero la longitud cambia 3 y resta 3-1=2 tomando los indices: 0,1
                {9, 7, 19}
                 */
                copia = Arrays.copyOf(copia, copia.length - 1); //copia.length - 1: son la cantidad de elementos que quieres copiar

            } else {
                i++; //incrementa si copia < valor, sino va al if y hace la eliminacion
            }

        }
        return copia;
    }
}
