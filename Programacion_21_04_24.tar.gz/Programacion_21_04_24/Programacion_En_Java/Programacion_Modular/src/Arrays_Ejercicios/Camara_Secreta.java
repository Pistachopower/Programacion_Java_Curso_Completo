/*
Desarrollar el juego “la cámara secreta” que consiste en abrir una cámara mediante su 
combinación secreta, que está formada por una combinación de dígitos del 1 al 5. El 
jugador especificará cuál es la longitud de la combinación; a mayor longitud, mayor 
será la dificultad del juego. La aplicación genera, de forma aleatoria, una combinación 
secreta que el usuario tendrá que acertar. En cada intento se muestra como pista, para 
cada dígito de la combinación introducido por el jugador, si es mayor, menor o igual 
que el correspondiente en la combinación secreta.

 */
package Arrays_Ejercicios;

import java.util.Arrays;
import java.util.Scanner;

public class Camara_Secreta {

    public static void main(String[] args) {
        //crea objeto teclado
        Scanner teclado = new Scanner(System.in);

        //variable guarda la cantidad de numeros del usuario
        int d_Camara;

//        System.out.println("****BIENVENIDOS***");
//        System.out.println("");
        System.out.println("¿Cuál es la dimensión de tu tabla?");
        d_Camara = teclado.nextInt();

        //llamamos a la funcion tabla_Secreta y la guardamos el array devuelto en otro array para usarlo en la funcion pistas
        int tabla_Secreta[] = tabla_Secreta_Aleatoria(d_Camara);

        //array que guarda la dimension de la tabla usuario
        int[] tabla_Usuario = new int[d_Camara];

//        System.out.println("Digita el número de tu tabla: ");
//        d_Camara = teclado.nextInt();

            System.out.println("tabla secreta " + Arrays.toString(tabla_Secreta));

        
        int i = 0; //para acceder a los valores de la tabla secreta
        for (int valor : tabla_Secreta) {

            
            
//            System.out.println("");
//            System.out.println("<<<<<<Tienes por cada índice 3 intentos>>>>>>");
//            System.out.println("");
            
            //por cada índice el usuario tendrá 3 intentos
            int intentos = 0;
            boolean pasar= false;
            
            //sale cuando una no se cumple
            while (intentos < 3 && pasar == false) {
                System.out.println("");
                System.out.println("<<Intento " + (intentos + 1)  + ">>"); //sumamos 1 para que se vea de forma normal
                System.out.println("");
                System.out.println("Digita el número de tu tabla del índice " +  (i+1) + ": "); //hacemos la suma para ver el indice del usuario
                d_Camara = teclado.nextInt();

                if (tabla_Secreta[i] > d_Camara) {
                    System.out.println("");
                    System.out.println("Pista: el número secreto es mayor que " + d_Camara);
                    System.out.println("");
                }
                //imprime que el numero secreto es menor que el digitado
                if (tabla_Secreta[i] < d_Camara) {
                    System.out.println("");
                    System.out.println("Pista: el número secreto es menor que " + d_Camara);
                    System.out.println("");
                }
                //imprime que los numeros son iguales
                if (tabla_Secreta[i] == d_Camara) {
                    System.out.println("");
                    System.out.println("¡Has acertado el dígito!");
                    tabla_Usuario[i] = d_Camara;
                    pasar= true; //para que recorra el siguiente indice de tabla secreta
                    
                }
                intentos++;

            }

            i++;
        }
        
        
        //comprobamos que los arrays tienen los mismos valores
        if (Arrays.equals(tabla_Secreta, tabla_Usuario)) {
            System.out.println("Cámara secreta abierta ");

            
        } else {
            System.out.println("");
            System.out.println("Lo siento, no has podido abrir la cámara secreta ");
        }

    }


    static int[] tabla_Secreta_Aleatoria(int dimension) {
        //array que guarda los numeros los números secretos 
        int tabla_Secreta[] = new int[dimension];

        //para iterar en el bucle
        int i = 0;

        //recorremos la tabla vacia y la llenamos con valores aleatorios
        while (i < dimension) {

            //creamos el numero aleatorio 
            int aleatorio = (int) (Math.random() * (5 - 1 + 1) + 1);

            //rellenamos e inccrementamos la tabla y la iteracion
            tabla_Secreta[i] = aleatorio;
            i++;

        }

        //Arrays.sort(pares);
        return (tabla_Secreta);
    }
}
