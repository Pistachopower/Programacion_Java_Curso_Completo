/*
Campeonato de programación (15/01)

Diseñar una aplicación para gestionar un campeonato de programación, 
donde se introduce la puntuación (enteros) obtenidos por 5 programadores, 
conforme van terminando su prueba. La aplicación debe mostrar las puntuaciones 
ordenadas de los 5 participantes. En ocasiones, cuando finalizan los 5 participantes anteriores, 
se suman al campeonato programadores de exhibición, cuyos puntos se incluyen con el resto. 
Se introducirá -1 para indicar que ya no van a intervenir más programadores de exhibición. 
La aplicación debe mostrar, finalmente, los puntos ordenados de todos los participantes.

 */
package Arrays_Ejercicios;

import java.util.Arrays;
import java.util.Scanner;

public class Campeonato_Programacion_Ejemplo_InsercionOrdenada_Marta {
    public static void main(String[] args) {
        /*
        Leeremos las puntuaciones en el orden en el que terminen los participantes y las ordenaremos.
        A continuacion realizaremos una insercion ordenada (por cada programador de exhibicion). Una 
        mala idea seria insertar al final la puntuacion de los programadores de exhibicion y volver a ordenar
        ya que esto es muy costoso en tiempo. Es mas eficiente una insercion ordenada
        */
        Scanner teclado = new Scanner(System.in);
        
        int puntos[]= new int[5]; //inicialmente intervienen 5 programadors
        
        for (int i = 0; i < 5; i++) {
            System.out.println("Puntos programador ("+ (i + 1) + "): ");
            puntos[i]= teclado.nextInt(); //leemos los datos que no estan ordenados
        }
        
        Arrays.sort(puntos); //ordenamos
        System.out.println("Puntuacion: " + Arrays.toString(puntos));
        
        System.out.println("Puntos del programador de exhibición: ");
        int puntosProgExh= teclado.nextInt(); //puntuacion del progr de exhibicion
        
        while (puntosProgExh != -1) {            
            int pos= Arrays.binarySearch(puntos, puntosProgExh); //buscamos y devolvemos el indice correcto para mantener la tabla ordenada
            
            int indiceInsercion; //donde insertar que guarda el valor existente o no existente 
            if (pos < 0) {
                indiceInsercion= - (pos) - 1; //obtenemos el correcto en donde va el valor en la tabla
            } else {
                indiceInsercion= pos; //puntuacion repetida, ya esta en la tabla
            }
            
            
            int copia[]= new int[puntos.length + 1 ]; //nueva tabla con longitud + 1
            //copiamos los elementos antes del hueco
            System.arraycopy(puntos, 0, copia, 0, indiceInsercion);
            //copiamos desplazados los elementos tras el hueco
            System.arraycopy(puntos, indiceInsercion,
                    copia, indiceInsercion + 1 , puntos.length - indiceInsercion);
            
            copia[indiceInsercion]= puntosProgExh; //asignamos el nuevo elemento
            
            puntos= copia; //puntos referencia la nueva tabla
            
            System.out.println("Puntos del programador de exhibicion: ");
            puntosProgExh= teclado.nextInt(); //puntuacion del programador de exhibiocion
        }
        
        
        System.out.println("Puntuacion final: " + Arrays.toString(puntos));
        
        
    }
}
