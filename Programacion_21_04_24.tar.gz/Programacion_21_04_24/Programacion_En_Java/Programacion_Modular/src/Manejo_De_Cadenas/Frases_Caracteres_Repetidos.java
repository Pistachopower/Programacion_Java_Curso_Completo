/*
disenar un algoritmo que lea del teclasdo una frase e indique para cada letra que aparece en la frasde cuantas veces se repite. 
Se consideraran iguales mayusculas y minusculas
 */
package Manejo_De_Cadenas;

import java.util.Arrays;
import java.util.Scanner;

public class Frases_Caracteres_Repetidos {

    public static void main(String[] args) {
        //
        Scanner teclado = new Scanner(System.in);

        String frase = "adioss";

//        System.out.println("Introduce la frase: ");
//        frase= teclado.nextLine();
        //pasamos a minusculas 
        frase = frase.toLowerCase();

        //convertimos la cadena en un array
        char[] array_Caracteres = frase.toCharArray();
        Arrays.sort(array_Caracteres);
        System.out.println(Arrays.toString(array_Caracteres));

        int veces = 0; //indica las veces que se repite el caracter 

        for (int i = 0; i < frase.length(); i++) {
            //estas variables se reinicializan en cada iteracion

            String letra= ""; //guarda la letra 

            for (int j = 0; j < frase.length(); j++) {
                //comparamos si la posicion del indice coicide con el valor del otro array
                if (array_Caracteres[i] == array_Caracteres[j]) {
                    veces++;
                    //letra = String.valueOf(array_Caracteres, array_Caracteres[i]);
                }

            }

            //imprimimos las veces que aparece la letra y el valor de la letra actual
            System.out.println("La letra " + array_Caracteres[i] + " aparece " + veces);

        }
    }

}
