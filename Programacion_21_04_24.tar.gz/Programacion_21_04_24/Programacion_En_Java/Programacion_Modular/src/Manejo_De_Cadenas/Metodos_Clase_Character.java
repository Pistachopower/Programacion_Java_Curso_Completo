package Manejo_De_Cadenas;

/**
 *
 * @author alumnado
 */
public class Metodos_Clase_Character {

    public static void main(String[] args) {
        /*
        Clasificacion de caracteres
        Digitos: 0 al 9
        Letras: todos los elementos del alfabeto (incluido minusculas y mayusculas) a, A, b, B ...
        Caracteres blancos= como espacio o el tabulador, etc
        Otros caracteres= signos de puntuacion, matematicos, etc
        
        Los métodos de Character para verificar si un carácter pertenece a alguno de estos grupos devuelven un booleano: true en 
        caso de que pertenezca o false en caso contrario.        
         */

        //Esto métodos son:
        
        
        //Conversion entre caracteres:
         //Static boolean Character.isLowerCase(char ch): saber si un caracter está en minuscula
        char ch = 'A';
        System.out.println(Character.isLowerCase(ch)); //devuelve true si esta en minuscula
        
        ////Static boolean Character.isLowerCase(char ch): saber si un caracter está en mayuscula
        System.out.println(Character.isUpperCase(ch)); //devuelve true si esta en mayuscula
        
        
        //Static boolean isDigit(char c). Saber si existe un digito dentro de un char
        char f= '7';
        
        System.out.println(Character.isDigit(f));

         //Static boolean isLetter(char c)
         
         f= 'h'; 

         System.out.println(Character.isLetter(f)); //saber si la variable c tiene una letra
         
        
         
         //Static boolean isSpaceChar(char c) //saber si hay un espacio en blanco
          f= ' ';
          System.out.println(Character.isSpaceChar(f));
         

          //Static boolean isWhitespace(char c) es lo mismo que la anterior
          System.out.println(Character.isWhitespace(f));
          
          /*
          TablaUnicode_SecuenciaDeEscape_ConversionChar_Int_AritmeticaCaracteres
        code point: un caracter que se representa con un numero entero, en decimal o hexadecimal
        */
        
       char c;
       
       c= 'a'; //directamente mediante el teclado
       c= 97; //usando el code point en decimal
       c= '\u0061'; //o con el code point en hexadecimal
       
       c= '\u0024';
       
        //System.out.println(c);
        
       /*
        Secuencia de escape= un caracter precedido de una barra \ 
        */

       char secuencia_Excape= '\''; //muestra una comilla simple
       
        System.out.println(secuencia_Excape);
               
        secuencia_Excape= '\"'; //muestra una comilla doble
        
        System.out.println(secuencia_Excape);
        
        //ejemplo
        String nombre= "Nelson";
        
        secuencia_Excape= '\t'; //tabulador
        
        System.out.println(secuencia_Excape + nombre);
        
        
        /*
        Conversion char  a int
            Se puede asignar a un tipo de dato char un entero y viceversa, siempre y cuando 
            esté en el rango permitido de 0 hasta 65.535
        
        */
        
        int e= 'a'; //asigna un caracter a una variable int
        
        System.out.println(e); //muestra el 97
        
        e= '\u0061'; //asigna un caracter a una variable int
        
        System.out.println(e); //muestra el 97
        
        char d= 97; //asigna un entero a una variable char
        
        System.out.println(d);
        
        /*
        Tambien es posible forzar una conversion por medio de un cast
        */
        d= 'a';
        
        System.out.println((int)d); //muestra el 97
        
        int x= 97; 
        
        System.out.println((char)x); //muestra 'a'
        
        /*
        se pueden realizar asignaciones de variables del tipo int a char con un cast, conocida conversion 
        por estrechamiento (cambia de datos de enteros a char y viceversa)
        */
        
        int q= 97;
        
        char w= (char) e; //w vale 'a'
        
        System.out.println(w);
        
        
        /*
        Aritmetica de caracteres (usando la tabla unicode)
        */
        
        
        // 'a' + 1= 61 (hexadecimal) + 1= 62 (hexadecimal) = 98 (decimal)
        System.out.println('a' + 1); //se muestra una 98 en la pantalla
        
       char r= 'e' - 2; //vale c buscando el valor en la tabla unicode
       
        System.out.println(r);
        
        r= 'e' + 2;
        
        System.out.println(r); //vale 'g'
        
        //'A' - 'a' representa la distancia que existe en el codigo Unicode entre las letras minusculas y las mayusculas
        char y= 'h' + 'A' - 'a';
        
        System.out.println(y); //muestra una 'H'


    }
}
