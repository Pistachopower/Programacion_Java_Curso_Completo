/*
Diseña una aplicación que pida al usuario que introduzca una frase por teclado e indique cuántos espacios en blaco tiene.   
 */
package Manejo_De_Cadenas;

import java.util.Scanner;

public class Cadena_Con_Espacios_En_Blanco {

    public static void main(String[] args) {
        /*
        Vamos a recorrer la cadena introducida por el usuario, comprobando caracter a caracter 
        si coincide con un espacio en blanco
        */
        Scanner teclado = new Scanner(System.in);
        String frase;
        
        int numEspaciosBlanco=0; //contador del numero de espacios en blanco
        char c;
        
        System.out.println("Escriba una frase: ");
        frase= teclado.nextLine(); 
        
        for (int i = 0; i < frase.length(); i++) { //recorremos del indice 0 a longitud - 1
            c= frase.charAt(i); //vemos cual es el i-esimo caracter
            if (Character.isSpaceChar(c)) { //es equivalente a: c == ' '
                numEspaciosBlanco++; //incrementamos
                
            }    
        }
        System.out.println("Tiene " + numEspaciosBlanco + " espacios en blanco");
            
        
    }
}
