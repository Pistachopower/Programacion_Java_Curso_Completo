/*
Se dispone de la siguiente relación de letras:

        conjunto1 = {'e', 'i', 'k', 'm', 'p', 'q', 'r', 's', 't', 'u', 'v'};
        conjunto2 = {'p', 'v', 'i', 'u', 'm', 't', 'e', 'r', 'k', 'q', 's'};


Con ella es posible codificar un texto, convirtiendo cada letra del conjunto 1 en su correspondiente del conjunto 2. El resto de las letras no se modifican. 
Los conjuntos se utilizan tanto para codificar mayúsculas como minúsculas, mostrando siempre la codificación en minúsculas.

Por ejemplo: la palabra “PaquiTo” se codifica como “matqvko”.

Realizar un programa que solicite al usuario un texto y muestre el texto codificado. Para ello, implementar una función que reciba un carácter a 
codificar y las referencias de las dos tablas tipo char correspondientes a los conjuntos 1 y 2, y devuelva el carácter codificado.


 */
package Manejo_De_Cadenas;

import java.util.Scanner;

public class codificar_Texto {

    public static void main(String[] args) {
/*
En primer lugar vamos a introducir el texto en minuscula, para que los alfabetos conjuntos 1 y 2 sirvan para las letras mayusculas y minusculas. 
El procedimiento a seguir sera recorrer y codificar el texto introducido, caracter a carater. La codificacion se almacenara en una tabla, que nos 
permite asignar valores (caracteres) a cada uno de sus elementos.        
        
        
*/        

        Scanner teclado = new Scanner(System.in);

        //definimos el array 
        char[] conjunto1 = {'e', 'i', 'k', 'm', 'p', 'q', 'r', 's', 't', 'u', 'v'};
        char[] conjunto2 = {'p', 'v', 'i', 'u', 'm', 't', 'e', 'r', 'k', 'q', 's'};

        char codificado[]; //tabla que contendra la codificacion del texto introducido
        
        
        //cadena que guarda el valor a codificar
        System.out.println("Introduce la cadena a codificar: ");
        String texto = teclado.nextLine();
        
        texto= texto.toLowerCase(); //convertimos el texto a minusculas, para poder codificar las mayusculas y las minusculas con el mismo conjunto
        
        //codifica las mayusculas y minusculas con el mismo conjunto 
        codificado = new char[texto.length()]; //creamosm una tabla de igual tamaño que texto
        
        for (int i = 0; i < texto.length(); i++) { //recorremos el texto a codificar 
            //modificamos el i-esimo caracter del texto
            codificado[i] = codifica(conjunto1, conjunto2, texto.charAt(i));
        }
        texto = String.valueOf(codificado); //convertimos la tabla con la codificacion en una cadena
        System.out.println(texto);
        
        
        
        

    }
    
    /*
    Esta funcion codifica el caracter c segun los alfabetos conjuntos 1 y 2. 
    Buscamos el caracter c en conjunto1. Si se encuentra en la posicion pos, 
    se devuelve el caracter equivalente en el segunfo conjunto: conjunto2[pos]
    En caso de no encontrar c en conjunto 1 se devuelve c sin codificar
    
    */
    
       static char codifica(char conjunto1[], char conjunto2[], char c) { 
        final String conj1 = String.valueOf(conjunto1); //conj1 es un string con los elementos de la tabla conjunto1. Facilita la busqueda
        char codificado; //caracter codificado correspondiente a c
        int pos = conj1.indexOf(c); //buscamos c en el conjunto 1. Al ser conj1 una cadena, indexOf() busca por nosotros. En otro caso, tendriamos que buscar mediante un bucle un elemento en una tabla
        if (pos == -1) { //si no hemos encontrado c en conj1
            codificado = c;//no podemos codificar, devolveremos c
        } else {
            codificado = conjunto2[pos]; //pos marca la posicion de c en conjunto1 entonces elegimos el correspondiente en conjunto2
        }
        return codificado;
    }
}
