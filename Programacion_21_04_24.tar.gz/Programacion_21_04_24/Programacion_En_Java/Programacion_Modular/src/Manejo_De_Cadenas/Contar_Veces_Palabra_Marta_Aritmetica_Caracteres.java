/*
Diseñar un programa que solicite al usuario una frase y una palabra. A continuación, buscará cuántas veces aparece la palabra en la frase.
 */
package Manejo_De_Cadenas;

import java.util.Arrays;
import java.util.Scanner;

public class Contar_Veces_Palabra_Marta_Aritmetica_Caracteres {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);  // Crea un objeto Scanner para leer la entrada del usuario
        String frase;  // Declara una variable de tipo String para almacenar la frase del usuario
        int[] numVecesPorLetra;  // Declara un array para contar el número de veces que cada letra aparece en la frase

        System.out.print("Introduzca una frase: ");  // Solicita al usuario que introduzca una frase
        frase = sc.nextLine();  // Lee la frase del usuario
        frase = frase.toLowerCase();  // Convierte la frase a minúsculas para facilitar el conteo de letras
        numVecesPorLetra = new int['z' - 'a' + 1];  // Inicializa el array con un tamaño de 26 (para cada letra del alfabeto)

// Este bucle recorre cada carácter de la frase
        for (int i = 0; i < frase.length(); i++) {
            // Si el carácter es una letra (ignora los espacios y otros caracteres)
            if (Character.isLetter(frase.charAt(i))) {
                // Incrementa el contador correspondiente a esa letra en el array
                numVecesPorLetra[frase.charAt(i) - 'a']++;
            }
        }

// Este bucle recorre el array de conteos
        for (int i = 0; i < numVecesPorLetra.length; i++) {
            // Si el contador para una letra no es cero (es decir, la letra aparece en la frase)
            if (numVecesPorLetra[i] != 0) {
                // Imprime la letra y el número de veces que aparece en la frase
                System.out.println("La letra " + (char) (i + 'a')
                        + " se repite " + numVecesPorLetra[i] + " veces");
            }
        }

    }

}
