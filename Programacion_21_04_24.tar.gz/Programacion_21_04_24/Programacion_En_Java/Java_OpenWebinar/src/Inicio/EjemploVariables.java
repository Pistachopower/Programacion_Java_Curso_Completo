
package Inicio;

public class EjemploVariables {
    public static void main(String[] args) {
        String msg= "Hola Mundo"; //declarar e iniciliazar [literales: lo que esta dentro de la variable]
        int x;//declarar variable
        msg= "Hasta luego"; //reinicializar la variable
        
        
    }
}
