package Inicio;

import java.util.Arrays;

/*
Escribir la función int [ ] rellenaPares(int longitud, int fin), que crea y devuelve 
una tabla ordenada de la longitud especificada, 
que se encuentra rellena con números pares aleatorios comprendidos en el rango desde 2 
hasta fin (inclusives). Usar método sort.

 */
public class Hoja_Libre {

    public static void main(String[] args) {
        int longitud = 3;
        int fin = 100;

        rellenaPares(longitud, fin);

    }

    static int[] rellenaPares(int longitud, int fin) {
        int num_Array[] = new int[longitud];

        for (int i = 0; i < num_Array.length; i++) {
            int aleatorio;

            do {
                aleatorio = (int) (Math.random() * fin + 2);
            } while (aleatorio % 2 != 0);

            num_Array[i] = aleatorio;
        }

        Arrays.sort(num_Array);

        for (int valor : num_Array) {
            System.out.println(valor);

        }

        return (num_Array);
    }

}
