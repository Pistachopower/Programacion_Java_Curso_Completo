# Biblioteca-DDR-Java

La biblioteca de Disco Duro de Roer, recopila todas las funciones realizadas en el canal y las mías propias de años de experiencia.

Javadoc del proyecto. https://www.discoduroderoer.es/doc-biblioteca-ddr/

Se dividen en varias secciones:

## Arrays 


Su intención es hacer todo aquello que este relacionado con los arrays, ya sea ordenar, mostrar, rellenar, etc.

Se subdivide en varias clases:

### Array

### Búsqueda

### MostrarArray

### OperacionesArray

### Ordenación

### RellenarArray


## Multi idioma


## Expresiones regulares 


## Fechas


### Anios

### Conversion

### Dias

### Horas

### Meses

### ValidacionesFechas


## Ficheros 


### Binarios

### MiObjectOutputStream

### RAF

### Rutas

### Serializacion

### Texto

## Matrices


### EstadoMatriz

### Matrices

### Mostrar

### Operaciones

### Posicion

### Rellenar

##  Números


### Aleatorios

### Calculo

### Conversion

### Numeros

### Validacion

## Palabras


### Palabras

## Swing


### FondoSwing

### LAF

### Limpiar

### MiSiwing

### Rellenar

### Validacion

## XML 

