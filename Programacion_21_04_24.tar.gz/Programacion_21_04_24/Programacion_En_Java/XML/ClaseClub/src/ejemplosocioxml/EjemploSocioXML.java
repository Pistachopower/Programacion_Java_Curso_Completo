/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplosocioxml;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.*;

/**
 *
 * @author alumnado
 */
public class EjemploSocioXML {

    public static void main(String[] args) {
       
        
        try {
            JAXBContext contexto = JAXBContext.newInstance(Club.class); 
            Unmarshaller um = contexto.createUnmarshaller();
            
            Club c = (Club) um.unmarshal(new FileReader("club.xml"));
            System.out.println(c.toString());
            
            
            Marshaller m = contexto.createMarshaller();
            Club c1 = new Club("Los Leones");
            Socio s1= new Socio(15, "nelson", "sevilla", "20/08/1969");
            
            c1.nuevoSocio(s1); //agrego el objeto de tipo socio
            
            
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE); //Establece salida formateada como XML para que no aparezca todo en una sola linea
            m.marshal(c1, new FileWriter("club1.xml"));
            m.marshal(c1, System.out);
            
        } catch (JAXBException | FileNotFoundException ex) {
            //Logger.getLogger(EjemploSocioXML.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(ex);
            
        } catch (IOException ex) {
            //Logger.getLogger(EjemploSocioXML.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(ex);
        }
        
//        try {
//            JAXBContext contexto = JAXBContext.newInstance(Club.class);
//            Unmarshaller um = contexto.createUnmarshaller();
//            
//            Club c = (Club) um.unmarshal(new FileReader("club.xml"));
//            System.out.println(c.toString());
//            
//        } catch (JAXBException | FileNotFoundException ex) {
//            System.out.println(ex);
//        }
        
    }
    
}
