/*
Una cola es una estructura dinamica como la pila, donde los elementos
en vez de apilarse y desapilarse, encolan y desencola. La diferencia
con las pilas es que se desencola el primer elemento encolado, 
ya que asi es como funcionan las colas del autobus o del cine.
El primero que llega, es el primero que sale de la cola
(vamos a suponer que nadie se cuela). Por lo tanto, los elementos
se encolan y desencolan en extremos opuestos de la estructuras, 
llamados primero (el que esta primero y sera el proximo en abandonar 
la cola) y último (el que llego ultimo). Imprementa la clase Cola 
donde los elementos integer encolados se guardan en una tabla.
 */
package cola;

public class Cola {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Clase_Cola t= new Clase_Cola();
        Clase_Cola t2= new Clase_Cola();
        
        
        t.apilar(10);
        t.apilar(5);
        
        t2.apilar(6);
        t2.apilar(5);
        
        t.concatenarObjetos(t2);
        
        
   
        
        
        t.mostrar();
    }
    
}
