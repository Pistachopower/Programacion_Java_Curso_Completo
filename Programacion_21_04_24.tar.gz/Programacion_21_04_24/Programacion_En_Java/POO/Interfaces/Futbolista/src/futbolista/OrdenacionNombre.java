/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package futbolista;

import java.util.Comparator;

/**
 *
 * @author nelson
 */
public class OrdenacionNombre implements Comparator {

    @Override
    public int compare(Object f, Object f2) {
         int resultado;
         Futbolista t_1= (Futbolista) f;
         Futbolista t_2= (Futbolista) f2;
         
         resultado= t_1.nombre.compareTo(t_2.nombre);
         
         return resultado ;
    }
    
}
