/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejerciciocomparablesocio;

import java.util.Arrays;

/**
 *
 * @author martarobina
 */
public class EjercicioComparableSocio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Socio socio1 = new Socio(3, "Pepa", "2000-04-30");
        Socio socio2 = new Socio(1, "Manolo", "1998-08-28");
        Socio socio3 = new Socio(39, "Ana", "2000-06-30");
        System.out.println(socio1);
        System.out.println(socio1.compareTo(socio2));
        
        
        Socio[] tabla = new Socio[]{socio3, socio1, socio2};
        
        System.out.println(Arrays.deepToString(tabla));
        
        /*Arrays.sort(tabla);
        
        System.out.println(Arrays.deepToString(tabla));
        
        ComparaEdades comparador1 = new ComparaEdades();
        
        System.out.println(comparador1.compare(socio1, socio2));
        
        Arrays.sort(tabla, comparador1);
        
        System.out.println(Arrays.deepToString(tabla));
             
        Arrays.sort(tabla, comparador1.reversed());
        System.out.println(Arrays.deepToString(tabla));*/
        
        ComparaNombres comparador2 = new ComparaNombres();
        
        //Arrays.sort(tabla, comparador2);
        Arrays.sort(tabla, comparador2.reversed());
        
        System.out.println(Arrays.deepToString(tabla));
        
        ComparaNombres cn = new ComparaNombres();
        
        System.out.println(cn.compare(socio1, socio2));
    }
    
}
