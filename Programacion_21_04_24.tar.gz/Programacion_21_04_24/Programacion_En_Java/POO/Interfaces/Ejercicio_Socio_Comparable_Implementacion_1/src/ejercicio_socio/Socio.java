/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_socio;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author nelson
 */
public class Socio implements Comparable {
        int id;
    String nombre;
    LocalDate fechaNacimiento;
    DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public Socio(int id, String nombre, String fechaNacimiento) {
        this.id = id;
        this.nombre = nombre;
        this.fechaNacimiento = LocalDate.parse(fechaNacimiento, formato);
    }

    //hacer implementacion de toString de la clase object, que muestre el id,
    //nombre, edad. Y para mostrar la edad se necesita un metodo edad privado 
    //(calcular la edad
    //pista metodo anti) y un overring de toString id, nombre, edad    
    public int edad() {
        LocalDate fechaActual = LocalDate.now(); // Obtiene la fecha actual

        Period periodo = fechaNacimiento.until(fechaActual); // Calcula el periodo entre las dos fechasc

        int edad = periodo.getYears(); // Obtiene los años del periodo, que es la edad

        return edad;
    }

    @Override
    public int compareTo(Object t) {
        Socio otroSocio = (Socio) t;
        int v = 0;

        if (this.id > otroSocio.id) {
            v = 1;

        }
        if (this.id < otroSocio.id) {
            v = -1;

        } else {
            v = 0;
        }
        return v;
    }

    @Override
    public String toString() {

        return "Socio{" + "id=" + id + ", nombre=" + nombre + ", fechaNacimiento=" + fechaNacimiento + " edad " + edad() + '}';
    }
}
