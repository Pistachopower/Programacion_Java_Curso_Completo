/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package supercola;

import java.util.Arrays;

/**
 *
 * @author nelson
 */
public class SuperCola implements Cola{
        int[] cola1;
    int[] cola2;

    public SuperCola() {
        cola1 = new int[0];
        cola2 = new int[0];
    }

    @Override
    public void encolar(int v) {
        cola1 = Arrays.copyOf(cola1, cola1.length + 1);
        cola1[cola1.length - 1] = v;
    }

    public void encolar2(int v) {
        cola2 = Arrays.copyOf(cola2, cola2.length + 1);
        cola2[cola2.length - 1] = v;
    }

    @Override
    public Object desencolar() {
        if (cola1.length == 0) {
            if (cola2.length == 0) {
                return null;
            } else {
                return desencolarCola2();
            }
        } else {
            return eliminarCola1(0);
        }
    }

    public Object desencolarCola2() {
        if (cola2.length == 0) {
            if (cola1.length == 0) {
                return null;
            } else {
                return eliminarCola1(0);
            }
        } else {
            return eliminarCola2(0);
        }
    }

    private Object eliminarCola1(int indice) {
        Object eliminado = null;
        if (indice >= 0 && indice < cola1.length) {
            eliminado = cola1[indice];
            for (int i = indice + 1; i < cola1.length; i++) {
                cola1[i - 1] = cola1[i];
            }
            cola1 = Arrays.copyOf(cola1, cola1.length - 1);
        }
        return eliminado;
    }

    private Object eliminarCola2(int indice) {
        Object eliminado = null;
        if (indice >= 0 && indice < cola2.length) {
            eliminado = cola2[indice];
            for (int i = indice + 1; i < cola2.length; i++) {
                cola2[i - 1] = cola2[i];
            }
            cola2 = Arrays.copyOf(cola2, cola2.length - 1);
        }
        return eliminado;
    }

    public String toString() {
        String c1 = Arrays.toString(cola1);
        String c2 = Arrays.toString(cola2);
        return "Cola1: " + c1 + " Cola2: " + c2;
    }
}
