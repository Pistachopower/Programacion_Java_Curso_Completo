/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ejemplo_interfaces;

/**
 *
 * @author alumnado
 */
public interface Sonido {

    //es una constante y estatico pero no se puede modificar
    int VERSION = 1;

    public void voz();

    default void vozDurmiendo() {
        System.out.println("zzzz");

    }
    
    //no pueden ser sobreescrito 
    static void bostezo() {
        System.out.println("Auuuuuuuu");
                
    }

}
