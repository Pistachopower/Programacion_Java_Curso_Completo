/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplo_interfaces;

/**
 *
 * @author alumnado
 */
public class Gato implements Sonido {

    @Override
    public void voz() {
        System.out.println("miau");
    }
    
    
    @Override
    public void vozDurmiendo() {
        System.out.println("rrr");

    }
    
    
}
