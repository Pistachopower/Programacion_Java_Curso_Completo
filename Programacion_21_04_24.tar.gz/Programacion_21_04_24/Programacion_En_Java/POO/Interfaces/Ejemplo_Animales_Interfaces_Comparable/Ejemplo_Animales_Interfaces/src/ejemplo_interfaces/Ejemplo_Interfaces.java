/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo_interfaces;

/**
 *
 * @author alumnado
 */
public class Ejemplo_Interfaces {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Perro perro1= new Perro();
        Perro perro2= new Perro();

        perro1.edad= 2;
        perro2.edad= 4;
        
        System.out.println(perro1.compareTo(perro2));
    }

}
