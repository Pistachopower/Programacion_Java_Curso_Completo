/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejerciciolistainterfacesclasesanonimas;

import java.util.Scanner;

/**
 *
 * @author martarobina
 */
public class EjercicioListaInterfacesClasesAnonimas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        
        Lista l = new Lista(); //aquí guardamos los números
        
        Cola cola = new Cola() {

            @Override
            public void encolar(int nuevo) {
                l.insertarFinal(nuevo);
            }

            @Override
            public int desencolar() {
                return l.eliminar(0);
            }
        };
        
        System.out.print("Introducir número(negativo para salir): ");
        int n = sc.nextInt();
        while (n >= 0) {
            cola.encolar(n);
            System.out.print("Introducir número: ");
            n = sc.nextInt();
        }
        n = cola.desencolar();
        System.out.print(n + " ");
        while (l.tabla.length!=0) {   
            n = cola.desencolar();
            System.out.print(n + " ");
        }
    }
    
}
