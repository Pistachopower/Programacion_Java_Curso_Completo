/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ordenarenterodescrecienteclasecomparadora;

import java.util.Comparator;

/**
 *
 * @author nelson
 */
public class ComparaEnterosInverso implements Comparator {

    @Override
    public int compare(Object t, Object t1) {
        return - ((Integer) t - (Integer) t1);
    }
    
}
