package ejercicio_socio;

import java.time.LocalDate;

import java.time.temporal.ChronoUnit;

public class Socio implements Comparable {

    int id;
    String nombre;
    LocalDate fechaNacimiento;
    

    public Socio(int id, String nombre, String fechaNacimiento) {
        this.id = id;
        this.nombre = nombre;
        this.fechaNacimiento =  LocalDate.parse(fechaNacimiento);
    }


    public int edad() {
         //int resultado;
        //resultado = fechaNacimiento.until(LocalDate.now()).getYears();
        
        //se pone un casteo de int porque until devuelve un tipo de dato long
        return (int) fechaNacimiento.until(LocalDate.now(), ChronoUnit.YEARS);
    }

//    @Override  //implementacion antigua: es para ver cómo se contruye por dentro la interfaz
//    public int compareTo(Object otro) {
//        int resultado;
//        Socio otroSocio = (Socio) otro;
//
//        if (this.id < otroSocio.id) {
//            resultado = -1;
//
//        }
//        if (this.id > otroSocio.id) {
//            resultado = 1;
//
//        } else {
//            resultado = 0;
//        }
//
//        return resultado = id - otroSocio.id;
//
//    }

    //
    @Override
    public int compareTo(Object otro) {
        int resultado;
        Socio otroSocio = (Socio) otro;
    
        resultado= edad() - otroSocio.edad();
        
        if (resultado == 0) {
            resultado = id - otroSocio.id;
        }
        return resultado;
                
        
    }
    
//       @Override
//    public int compareTo(Object o){
//        Socio otroSocio = (Socio)o;
//        return id - otroSocio.id;
//        //return nombre.compareTo(otroSocio.nombre);
//    }
    
    
    @Override
    public String toString() {

        return "ID: " + id + "  Nombre: " + nombre + "  Edad: " + edad() + "\n";
        //return "Socio{" + "id=" + id + ", nombre=" + nombre + ", fechaNacimiento=" + 
                //fechaNacimiento + " edad " + edad() +  "\n"+'}';
    }
}
