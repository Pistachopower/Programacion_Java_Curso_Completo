package Interfaces;

import java.util.Scanner;

/**
 * definir la interfaz cola para numeros enteros (debe tener encolar y
 * desencolar)
 *
 * la clase lista debe implentar la clase cola
 *
 *
 *
 * escribir un programa en que se encole numeros enteros positivo hasta que se
 * ponga un negativo. A continuacion desencolar todos y mostrarlos por pantalla
 */
public class Ejercicio_Interfaces {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //creamos el objeto lista vacio
        Lista l = new Lista();
        
        l.insertarFinal(3);
        l.insertarFinal(7);
        l.insertarFinal(9);
        l.insertarFinal(5);
        
        l.eliminar(2);
        
        

        //pedimos el numero para encolar
//        System.out.println("Introduce el numero: ");
//        int n = new Scanner(System.in).nextInt();
//
//        while (n >= 0) {
//
//            l.encolar(n);
//
//            //volvemos a pedir
//            System.out.println("Introduce el numero: ");
//            n = new Scanner(System.in).nextInt();
//
//        }
//        
//        //desencolar
//        for (int i = 0; i < l.numeroElementos(); i++) {
//            //l.mostrar();
//            int valor_Eliminado= l.desencolar();
//            System.out.println("Valor eliminado: " + valor_Eliminado);
//                    
//        }



        //pedimos el numero para desapilar
//        System.out.println("Introduce el numero a apilar: ");
//        int n = new Scanner(System.in).nextInt();
//
//        while (n >= 0) {
//
//            l.apilar(n);
//
//            //volvemos a pedir
//            System.out.println("Introduce el numero a apilar: ");
//            n = new Scanner(System.in).nextInt();
//
//        }
//        
//        for (int i = 0; i <= l.numeroElementos(); i++) {
//            int elementoEliminado= l.desapilar();
//            System.out.println(elementoEliminado);
//            
//        }
        




    }

}
