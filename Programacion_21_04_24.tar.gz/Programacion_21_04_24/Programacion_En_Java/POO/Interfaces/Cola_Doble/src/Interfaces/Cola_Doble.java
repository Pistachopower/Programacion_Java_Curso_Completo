
package Interfaces;

public interface Cola_Doble extends Cola {
    public void encolarPrincipio(int elemento1);
    
    public int desencolarFinal();

}


