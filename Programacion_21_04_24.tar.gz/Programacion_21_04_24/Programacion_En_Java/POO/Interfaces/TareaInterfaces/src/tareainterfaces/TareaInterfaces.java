/*
a) Implementar la clase Jornada, cuyos objetos son los datos
de cada d�a de trabajo de cada empleado de una empresa. En ella se
identificar� al trabajador por su DNI (constante String) y figurar�n la
fecha (LocalDate) y las horas de entrada y salida del trabajo de cada
jornada (LocalTime). Para crear el objeto se necesitar�n todos sus
datos. Un m�todo computar� el n�mero de minutos trabajados en la
jornada, devolviendo un tipo int. El criterio de orden natural de las
jornadas ser� el de los DNI, y para igual DNI, el de la fecha de la
jornada, con objeto de que aparezcan consecutivas todas las jornadas de
cada trabajador. Asimismo, implementar el m�todo toString() que muestre
el DNI del empleado, la fecha y la duraci�n en minutos de las jornadas.
b)
Usar la clase Lista de elementos Object para almacenar tres jornadas de
empleados, dos de ellas con el mismo dni. Una vez insertadas, ordenar
la lista y mostrar por pantalla sus elementos. Deb�is usar el m�todo of
de LocalDate y LocalTime para crear los objetos de cada tipo que se pasar�n como par�metros al constructor de Jornada.
c)
Implementar una clase comparadora para ordenar las jornadas de trabajo
por orden de n�mero de minutos trabajados. Ordenar la lista del apartado
anterior por dicho orden y mostrarla por pantalla.
Notas: 

    El m�todo until de LocalTime calcula el tiempo transcurrido entre el
    objeto invocante y el que se le pasa como par�metro, medido en la unidad
    que se le pasa como segundo par�metro (ChronoUnit.MINUTES para
    minutos). Devuelve el resultado en tipo long.
    Recuerda
    que las clases String y LocalDate implementan Comparable, es decir,
    tienen su propia implementaci�n del m�todo compareTo.
    Separar en el programa principal lo correspondiente a los apartados b y c (con correspondientes comentarios).
    Comenta el c�digo para que sea entendible. Eso os ayudar� a la hora de repasar en casa.
    Enviar carpeta comprimida con el proyecto.
 */
package tareainterfaces;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * @author marta
 */
public class TareaInterfaces {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Lista l = new Lista();
        
        // Apartado d
        l.insertarFinal(new Jornada("32", LocalDate.of(2021, 6, 13),
                LocalTime.of(8, 0), LocalTime.of(15, 30)));
        l.insertarFinal(new Jornada("21", LocalDate.of(2021, 7, 18),
                LocalTime.of(8, 0), LocalTime.of(15, 25)));
        l.insertarFinal(new Jornada("32", LocalDate.of(2021, 4, 9),
                LocalTime.of(8, 0), LocalTime.of(15, 0)));

        l.ordenar();

        System.out.println(l.toString());
        
        // Apartado e

        ComparaTiempos c = new ComparaTiempos();
        l.ordenar(c);

        System.out.println(l.toString());
    }
    
}
