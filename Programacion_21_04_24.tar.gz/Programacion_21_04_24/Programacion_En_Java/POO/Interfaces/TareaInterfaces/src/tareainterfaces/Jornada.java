/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tareainterfaces;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

/**
 *
 * @author marta
 */
public class Jornada implements Comparable {

    final String DNI_EMPLEADO;
    LocalDate fechaJornada;
    LocalTime horaEntrada;
    LocalTime horaSalida;

    public Jornada(String dniEmpleado, LocalDate fechaJornada,
            LocalTime horaEntrada, LocalTime horaSalida) {
        this.DNI_EMPLEADO = dniEmpleado;
        this.fechaJornada = fechaJornada;
        this.horaEntrada = horaEntrada;
        this.horaSalida = horaSalida;
    }

    int tiempoTrabajado() {
        return (int) horaEntrada.until(horaSalida, ChronoUnit.MINUTES);
    }

    @Override
    public int compareTo(Object ob) {
        int res;
        //int res = tiempoTrabajado() - ((Jornada) ob).tiempoTrabajado();
        //if (res == 0) {
            res = DNI_EMPLEADO.compareTo(((Jornada) ob).DNI_EMPLEADO);
        //}
        if (res == 0) {
            res = fechaJornada.compareTo(((Jornada) ob).fechaJornada);
        }
        return res;
    }

    @Override
    public String toString() {
        return "\nDNI: " + DNI_EMPLEADO + " fecha: " + fechaJornada
                + " minutos trabajados: " + tiempoTrabajado();
    }
    
}
