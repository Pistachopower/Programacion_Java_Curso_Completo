/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplo_claseanomina;

import java.util.Arrays;

/**
 *
 * @author alumnado
 */
public class Lista implements Cola {
       public int[] tabla;

    public Lista() {
        tabla = new int[0];
    }

    void insertarPrincipio(int nuevo) {
        tabla = Arrays.copyOf(tabla, tabla.length + 1);
        System.arraycopy(tabla, 0, tabla, 1, tabla.length - 1);
        tabla[0] = nuevo;
    }

    void insertarFinal(int nuevo) {
        tabla = Arrays.copyOf(tabla, tabla.length + 1);
        tabla[tabla.length - 1] = nuevo;
    }

    void insertarFinal(Lista otraLista) {
        int tamIni = tabla.length;
        tabla = Arrays.copyOf(tabla, tabla.length + otraLista.tabla.length);
        System.arraycopy(otraLista.tabla, 0, tabla, tamIni, otraLista.tabla.length);
    }

    void insertar(int posicion, int nuevo) {
        tabla = Arrays.copyOf(tabla, tabla.length + 1);
        System.arraycopy(tabla, posicion, tabla, posicion + 1,
                tabla.length - posicion - 1);
        tabla[posicion] = nuevo;
    }

    int eliminar(int indice) {
        int eliminado = -1;   // devuelve -1 si el índice no está dentro del rango correspondiente
        if (indice >= 0 && indice < tabla.length) {
            eliminado = tabla[indice];
            
            for (int i = indice + 1; i < tabla.length; i++) { //esta linea lo que hace es eliminar 
                tabla[i - 1] = tabla[i]; //elementos de cualquier posicion 
            }
            tabla = Arrays.copyOf(tabla, tabla.length - 1);
        }
        return eliminado;
    }

    int get(int indice) {
        int resultado = -1;   // devuelve -1 si el índice no está dentro del rango correspondiente
        if (indice >= 0 && indice < tabla.length) {
            resultado = tabla[indice];
        }
        return resultado;
    }

    int buscar(int claveBusqueda) {
        int indice = -1;  // devuelve -1 si no lo encuentra
        for (int i = 0; i < tabla.length && indice == -1; i++) {
            if (tabla[i] == claveBusqueda) {
                indice = i;
            }
        }
        return indice;
    }

    public int numeroElementos() {
        return tabla.length;
    }

    public void mostrar() {
        System.out.println("Lista: " + Arrays.toString(tabla));
    }

    
//metodos de interfaces
    @Override
    public void encolar(int v) {
        if (v >= 0) {
            insertarFinal(v);
        } else {
            System.out.println("El elemento " + v + " no se ha podido encolar.");
        }
    }

    @Override
    public int desencolar() {
        int valorEliminado= eliminar(0);
        
        return valorEliminado;
    }
    
}
