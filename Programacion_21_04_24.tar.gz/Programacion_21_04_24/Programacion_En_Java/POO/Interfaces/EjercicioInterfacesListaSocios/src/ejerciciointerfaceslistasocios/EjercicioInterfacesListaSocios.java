/*
Usar la clase Lista (tipo Object) para insertar 4 elementos de tipo Socio 
(a elección del programador). El orden natural de dichos elementos será la 
edad en modo creciente. Ordenar la tabla y mostrarla antes y después de 
ordenarla. Además, manteniendo el mismo orden natural, ordenar la lista 
de socios por orden creciente de id, y mostrarla de nuevo.

        // Ejercicio lista de cadenas de caracteres
//        Scanner sc = new Scanner(System.in);
//        Lista lcadenas = new Lista();
//        System.out.print("Introducir cadena (\"fin\" para terminar): ");
//        String cad = sc.nextLine();
//        
//        while (!cad.equals("fin")) {
//            lcadenas.insertarFinal(cad);
//            System.out.print("Introducir cadena (\"fin\" para terminar): ");
//            cad = sc.nextLine();
//        }
//        System.out.println(lcadenas);
//        lcadenas.ordenar();
//        System.out.println(lcadenas);
        
        // Ejercicio lista de objetos tipo Socio

 */
package ejerciciointerfaceslistasocios;

import java.util.Scanner;


public class EjercicioInterfacesListaSocios {

    public static void main(String[] args) {
        Lista l = new Lista();

        l.insertarFinal(new Socio(7, "Ignacio", "2005-12-03"));
        l.insertarFinal(new Socio(1, "Petra", "2005-12-13"));
        l.insertarFinal(new Socio(3, "Julio", "2003-11-01"));
        l.insertarFinal(new Socio(8, "Lisa", "2004-07-24"));
        
        System.out.println(l);
        
        l.ordenar();
        
        System.out.println(l);
        
        ComparaIds cid = new ComparaIds();
        
        l.ordenar(cid);
        
        System.out.println(l);
    }
    
}
