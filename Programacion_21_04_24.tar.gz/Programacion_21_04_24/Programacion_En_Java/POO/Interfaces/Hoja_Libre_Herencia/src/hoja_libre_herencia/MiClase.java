/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hoja_libre_herencia;

/**
 *
 * @author nelson
 */
public class MiClase implements MiInterfaz {
    
    @Override
    public void miMetodoAbstracto(){
        System.out.println("Implementacion del metodo abstracto en MiClase");
    }
    
    
}
