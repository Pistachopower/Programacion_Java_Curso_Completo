/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_socio;

import java.util.Comparator;

/**
 *
 * @author alumnado
 */
public class ComparadoraNombre implements Comparator {

    @Override
    public int compare(Object t, Object t2) {
        Socio socio1= (Socio) t;
        Socio socio2= (Socio) t2;
        
        return (socio1.nombre.compareTo(socio2.nombre));
    }


    
}
