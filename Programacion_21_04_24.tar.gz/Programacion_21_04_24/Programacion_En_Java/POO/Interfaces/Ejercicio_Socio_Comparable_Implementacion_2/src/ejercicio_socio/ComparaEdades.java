/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_socio;

import java.util.Comparator;

public class ComparaEdades implements Comparator {

    @Override
    public int compare(Object t1, Object t2) {
        Socio socio1= (Socio) t1;
        Socio socio2= (Socio) t2;
        
        return socio1.edad() - socio2.edad();
    }
    
}
