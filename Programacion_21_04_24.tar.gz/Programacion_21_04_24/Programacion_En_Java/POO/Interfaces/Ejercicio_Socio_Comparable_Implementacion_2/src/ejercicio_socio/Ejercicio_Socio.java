/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_socio;

import java.util.Arrays;

/**
 *
 * @author nelson
 */
public class Ejercicio_Socio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //EJEMPLO ORDENAR MEDIANTE ATRIBUTOS CON Comparable
        Socio[] t = new Socio[]{
            new Socio(2, "Ana", "1995-12-07"),
            new Socio(5, "Jorge", "2002-01-20"),
            new Socio(1, "Juan", "2004-05-06"),};
//        
//        
//       Arrays.sort(t);
//       
//        System.out.println(Arrays.deepToString(t));

        //Ejemplo ordenar por la edad
        //Nos creamos una clase llamada ComparaEdades para poder comparar las edades
        //ComparaEdades comparador1 = new ComparaEdades();
//        
//        //que pasaremos al metodo sort() como argumento, junto con la tabla que queremos ordenar
//   
//        Arrays.sort(t, comparador1);
//        
//        
//        
//        System.out.println(Arrays.deepToString(t));
        //Ejemplo ordenar por nombre 
        //ComparadoraNombre comparadorNombre = new ComparadoraNombre();
//
//        Arrays.sort(t, comparadorNombre);
//
//        System.out.println(Arrays.deepToString(t));

 
        //Vamos a probar el metodo reversed de Comparator que sirve para poner los valores 
        //en orden descreciente
//        Arrays.sort(t, comparador1.reversed());
//        System.out.println(Arrays.deepToString(t));

        //System.out.println(comparador1.reversed());
    
       

    }

}
