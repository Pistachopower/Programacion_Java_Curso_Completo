/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package companiatelecomunicaciones;


import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;


/**
 *
 * @author nelson
 */
public class Llamada implements Comparable {

    int num_Tele_Cli;
    int num_Tele_Interl;
    boolean llamada_Saliente;
    LocalDate fecha;
    LocalTime fecha_Hora_Inicio_llamada;
    LocalTime fecha_Hora_Fin_llamada;
    Zona_Interlocutor zona_Interlocu;
    final double[] TARIFAS_ZONAS = {0.50, 0.20, 0.10, 0.05, 0.03};

    public Llamada(int num_Tele_Cli, int num_Tele_Interl, boolean llamada_Saliente, LocalTime fecha_Hora_Inicio_lla,Zona_Interlocutor zona_Interlocu) {
        this.num_Tele_Cli = num_Tele_Cli;
        this.num_Tele_Interl = num_Tele_Interl;
        this.llamada_Saliente = llamada_Saliente;
        this.fecha_Hora_Inicio_llamada = fecha_Hora_Inicio_lla;
        this.fecha= LocalDate.now();
        
        //this.fecha_Hora_Fin_llamada = LocalDateTime.now();
        this.zona_Interlocu = zona_Interlocu;
    }

    /*
    En la clase se establecerá un orden natural compuesto
    basado en el numero de telefono del cliente como primer criterio y en la fecha y hora
    de inicio como segundo criterio.
     */
    @Override
    public int compareTo(Object t) {
        Llamada datosLlamada = (Llamada) t;
        int respuesta;

        respuesta = num_Tele_Cli - datosLlamada.num_Tele_Cli;

        if (respuesta == 0) {
            respuesta = fecha_Hora_Inicio_llamada.compareTo(datosLlamada.fecha_Hora_Inicio_llamada);
        }

        return respuesta;
    }

    /*
    Asimismo, se implementará un método que devuelva
la duración en minutos de la llamada y otro que calcule su coste, si es saliente. 
     */
    public int duracionMinutos() {
        //se pone aqui fin de la llamada porque se supone que al calcular el coste, 
        //la llamada a terminado
        //return (int) horaEntrada.until(horaSalida, ChronoUnit.MINUTES);
        
       this.fecha_Hora_Fin_llamada = LocalTime.now();
        int horaF= (int) fecha_Hora_Inicio_llamada.until(fecha_Hora_Fin_llamada, ChronoUnit.MINUTES);

        
        return horaF;
    }
    
    


    public double costeLlamada() {
        double precio=0;
        
        if (llamada_Saliente == true) {
            //buscamos la zona
            //TARIFAS_ZONAS = {0.50, 0.20, 0.10, 0.05, 0.03};
            //MADRID, SEVILLA, CANARIAS, ASTURIAS, ARAGON
            switch (this.zona_Interlocu) {
                case MADRID:
                    precio= duracionMinutos() * TARIFAS_ZONAS[0];
                    break;
                case SEVILLA:
                    precio= duracionMinutos() * TARIFAS_ZONAS[1];
                    break;
                case CANARIAS:
                    precio= duracionMinutos() *  TARIFAS_ZONAS[2];
                    break;
                case ASTURIAS:
                    precio= duracionMinutos() *  TARIFAS_ZONAS[3];
                    break;
                case ARAGON:
                    precio= duracionMinutos() *  TARIFAS_ZONAS[4];
                    break;
                default:
                    break;
            }
            
        }
        return precio;
    }

    //FALTA AGREGAR DURACION EN MINUTOS Y COSTE LLAMADA
    @Override
    public String toString() {
        return "Llamada: " + "num_Tele_Cli=" + num_Tele_Cli + ", num_Tele_Interl=" + num_Tele_Interl
                + ", fecha_Hora_Inicio_llamada=" + fecha_Hora_Inicio_llamada + " fecha="  + fecha + " Duracion en minutos: " + 
                duracionMinutos() + " coste= " + costeLlamada() + "\n";
    }



    
}
