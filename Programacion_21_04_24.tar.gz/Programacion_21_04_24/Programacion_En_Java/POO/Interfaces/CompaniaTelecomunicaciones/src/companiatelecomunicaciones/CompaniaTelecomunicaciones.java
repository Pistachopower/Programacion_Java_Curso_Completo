
package companiatelecomunicaciones;

import java.time.LocalTime;
import java.util.Arrays;

/*
En una compañia de telecomunicaciones se desea registrar los datos de todas las llamadas de sus cliente.
Implementar la clase Llamada, que guardará los siguientes datos: numero de telefono del cliente, 
numero del interlocutor, atributo booleano que indique si la llamada es saliente, fecha y hora
del inicio de llamada y del fin, atributo enumerado que indique la zona del interlocutor
(suponer cinco zonas con tarifas distintas) y tabla constantes con las tarifas de las 
zonas en centimos de euros/minutos. En la clase se establecerá un orden natural compuesto
basado en el numero de telefono del cliente como primer criterio y en la fecha y hora
de inicio como segundo criterio. Asimismo, se implementará un método que devuelva
la duración en minutos de la llamada y otro que calcule su coste, si es saliente. 
Por último, implementar el metodo toString(), que muestre los dos numeros de 
telefono, la fecha y hora del inicio, la duracion y el coste
 */
public class CompaniaTelecomunicaciones {

    public static void main(String[] args) {
//        Llamada l1= new Llamada(6020291, 3523155, true, LocalTime.of(0, 1),
//                Zona_Interlocutor.CANARIAS);
//        Llamada l2= new Llamada(6020291, 3523155, true, LocalTime.of(0, 2),
//                Zona_Interlocutor.ASTURIAS);
//        Llamada l3= new Llamada(6020291, 3523154, true, LocalTime.of(0, 1),
//                Zona_Interlocutor.SEVILLA);
//        
//        Llamada[] listaLlamada= new Llamada[3];
//        
//        listaLlamada[0]= l1;
//        listaLlamada[1]= l2;
//        listaLlamada[2]= l3;
        
       
        
        
        //System.out.println(l1.toString());
        

        Llamada[] listaLlamada= new Llamada[] {
            new Llamada(6020291, 3523155, true, LocalTime.of(0, 1),
                Zona_Interlocutor.CANARIAS),
            new Llamada(6020291, 3523155, true, LocalTime.of(0, 2),
                Zona_Interlocutor.ASTURIAS),
            new Llamada(6020291, 3523154, true, LocalTime.of(0, 1),
                Zona_Interlocutor.SEVILLA)
        
        };
        
 Arrays.sort(listaLlamada);
        
        System.out.println(Arrays.deepToString(listaLlamada));
        
        
        
    }
    
}
