
package punto;

/**
Escribe la clase punto que representa un punto en el plano (con un componente x
* y un componente y), con los metodos:
1-Punto (double x, double y): construye un objeto con los datos pasado por parametro
2-void desplazaX(double dx): incrementa el componente x en la cantidad dx
3-void desplazaY(double dy): incrementa el componente y en la cantidad dy
4-void desplaza(double dx, double dy): desplaza ambos componentes segun las
* cantidades dx(en el eje x) y dy (en el componente y)
5-double distanciaEuclidea(Punto otro): calcula y devuelve la distancia 
* euclidea entre el punto invocante y el punto otro
 */
public class Punto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ClasePunto p= new ClasePunto(1.0, 2.0);
        ClasePunto p2= new ClasePunto(4.0, 6.0);
        
        p.desplazaX(3.0);
        p.desplazaY(2.0);
        
        p.desplaza(2.0, 3.0);
        
        
        
        System.out.println(p.distanciaEuclidea(p2));
                
        
        
        p.mostrar();
        
        
        
    }
    
}
