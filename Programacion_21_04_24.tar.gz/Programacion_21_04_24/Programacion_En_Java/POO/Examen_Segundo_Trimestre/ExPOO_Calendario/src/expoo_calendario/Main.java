/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package expoo_calendario;

/**
 *
 * @author marta
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

      Calendario c = new Calendario(31, 12, 2021);
      c.mostrar();
      c.incrementarDia();
      c.mostrar();
      c.incrementaMes();
      c.mostrar();
      
      Calendario a = new Calendario(1, 3, 2022);
      System.out.println("Iguales: " + c.iguales(a));
    }
    
}
