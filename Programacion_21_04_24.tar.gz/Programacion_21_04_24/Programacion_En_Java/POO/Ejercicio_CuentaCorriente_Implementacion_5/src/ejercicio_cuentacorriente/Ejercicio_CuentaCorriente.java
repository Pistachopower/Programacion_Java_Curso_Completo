package ejercicio_cuentacorriente;

/*
Existen gestores que administran cuentas bancarias y atienden a sus propietarios. 
Cada cuenta, en caso de tenerlo, cuenta con un único gestor. Diseñar la clase Gestor de la que interesa guardar
su nombre, teléfono y el importe máximo autorizado con el que se puede operar. Con respecto a los gestores, 
existen las siguientes restricciones:
Un gestor tendrá siempre un nombre y un teléfono.
Si no se asigna, el importe máximo autorizado por operación será de 10000 euros.
Un gestor, una vez asignado, no podrá cambiar su número de teléfono. Y todo el mundo podrá consultarlo.
El nombre será público y el importe máximo sólo será visible por clases vecinas.
Modificar la clase CuentaCorriente para que pueda disponer de un objeto Gestor. Escribir los métodos necesarios.
 */
public class Ejercicio_CuentaCorriente {

    public static void main(String[] args) {
        CuentaCorriente c1, c2, c3;

        Gestor g1 = new Gestor("Antonio González", "666 555 444");
        Gestor g2 = new Gestor("Bea Rodríguez", "987 543 210", 12000.0);

        c1 = new CuentaCorriente("12345678-A", "Pepita", g1);
        c2 = new CuentaCorriente("98765432-Z", "Ana", g1);
        c3 = new CuentaCorriente("11222333-B", "Sancho");
        //c3.gestor = g2;
        c3.setGestor(g2);
        c1.mostrarInformacion();
        c2.mostrarInformacion();
        c3.mostrarInformacion();

        c1.setGestor(g2);
        c1.mostrarInformacion();

    }

}
