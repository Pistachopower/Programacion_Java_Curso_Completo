
package persona_teoria;

public class Empleado extends Persona{
    
    double salario;
    
    public Empleado(String nombre, int edad, double estatura, double salario) {
        super(nombre, edad, estatura);
        this.salario= salario;
        
    }
    
    
   public String toString() {
       String cad= super.toString();
       return cad + "\nSalario del empleado: " +salario;
   
   }


   
   
   

    
    
    
    

    
}
