/*
Ejercicio 2 (5 puntos): Diseña la clase Calendario que representa una fecha concreta (año, mes
y día). La clase debe disponer de los métodos:
- Calendario(int año, int mes, int dia): donde se comprobará que la fecha sea correcta
mediante un método que pondrá a 1 los atributos que tengan un valor incorrecto (por
ejemplo, para el 30 de febrero, pondrá el día a 1). El año se considerará correcto a
partir del año 1 en adelante.
- void incrementarDia(): que incrementa en un día la fecha del calendario.
- void incrementarMes(): que incrementa en un mes la fecha del calendario.
- void incrementarAño(int cantidad): que incrementa la fecha del calendario en el
número de años especificados.
- void mostrar(): muestra la fecha por consola, con el formato día/mes/año (no hace
falta poner 0 delante de los valores de una cifra).
- boolean iguales(Calendario otraFecha): que determina si la fecha invocante y la que se
pasa por parámetro son iguales o distintas.
Los atributos de un objeto no se podrán modificar fuera de la propia clase de manera directa,
sino sólo a través de los métodos de incremento. Tampoco habrá forma de leer sus valores
fuera de la clase.
Siempre que se pueda, se deberá evitar sobrescribir código, para lo que se invocarán métodos
ya creados en la clase.
Para simplificar, no tendremos en cuenta los años bisiestos.

En el programa principal, se crearán varios objetos de tipo Calendario, alguno de ellos con
algún valor incorrecto, y se realizarán llamadas a los métodos de incrementar, mostrar y
comparar.
 */
package calendario;

public class Calendario {

    public static void main(String[] args) {
      Clase_Calendario c = new Clase_Calendario(31, 2, 2021);
//      
//      //c.incrementarDia();
//      //c.incrementaMes();
//      c.incrementaAño();
//      c.mostrar();
      
      
//      c.mostrar();
//      c.incrementarDia();
//      c.mostrar();
//      c.incrementaMes();
//      c.mostrar();
//      
//      Clase_Calendario a = new Clase_Calendario(1, 3, 2022);
//      System.out.println("Iguales: " + c.iguales(a));
        
    }
    
}
