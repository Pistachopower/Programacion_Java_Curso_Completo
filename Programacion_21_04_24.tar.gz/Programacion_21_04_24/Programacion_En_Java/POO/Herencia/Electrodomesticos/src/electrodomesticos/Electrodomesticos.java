/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package electrodomesticos;

/**
 *
 * @author nelson
 */
public class Electrodomesticos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        ClaseElectrodomesticos c_E= new ClaseElectrodomesticos(150, "azul", 'f', 5, 5);
        
        Lavadora l= new  Lavadora(150, "azul", 'f', 5, 5, 35);
        
        Television t= new Television(96, "negro", 'f', 5, 5, 10, true);
        
        //al incrementar su precio deberia cambiar el precio
        l.precioFinal();
        
        
        System.out.println(t.precioFinal());
        
        //precio sale a 5
        System.out.println(t);
    }
    
}
