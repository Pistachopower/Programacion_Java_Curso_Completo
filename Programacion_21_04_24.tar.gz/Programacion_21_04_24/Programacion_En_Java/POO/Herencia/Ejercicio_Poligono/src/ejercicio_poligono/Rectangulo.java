/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_poligono;

/**
 *
 * @author nelson
 */
public class Rectangulo extends Poligono {

    public Rectangulo(double b, double a) {
        super.base= b;
        super.altura= a;
    }
    
     
    
    @Override
    public double area() {
        double r= (base * altura);
        
        
        return r;
    }
    
}
