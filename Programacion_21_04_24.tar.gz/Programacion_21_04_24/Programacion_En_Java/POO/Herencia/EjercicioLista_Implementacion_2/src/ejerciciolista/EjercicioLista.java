/*


                    NUEVA IMPLEMENTACION
Un conjunto es un objeto similar a las listas, capaz de guardar valores de un tipo determinado, 
con la diferencia de que sus elementos no pueden estar repetidos. Escribe la clase Conjunto 
para enteros, heredando de Lista y reimplementando los métodos de inserción (void insertarPrincipio
(int nuevo) y void insertarFinal  (int nuevo)) para evitar las repeticiones.

Implementa también el método equals() en la clase Conjunto. Dos conjuntos se consideran 
iguales si tienen los mismos elementos, no importa en qué orden.

Añade un método abstracto a la clase Lista (void mostrarTipoLista()), que deberá implementarse 
en Conjunto mostrando un mensaje por consola indicando que es un conjunto. Eliminar en la clase 
Lista los métodos que instancien la clase Lista.

En el programa principal, crear un objeto Conjunto, insertar 3 valores al principio, 3 valores 
al final y mostrar la correspondiente tabla. Además, crear otro conjunto con los valores que se 
deseen y comparar los dos conjuntos creados mostrando por pantalla sin son o no iguales. 


*/
package ejerciciolista;


public class EjercicioLista {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Conjunto c1=new Conjunto();
        c1.insertarPrincipio(1);
        c1.insertarPrincipio(1);
        c1.insertarPrincipio(2);
        c1.insertarFinal(1);
        c1.insertarFinal(1);
        c1.insertarFinal(3);
        System.out.println(c1);
        
        Conjunto c2 = new Conjunto();
        c2.insertarPrincipio(3);
        c2.insertarPrincipio(2);
        c2.insertarPrincipio(1);
        System.out.println(c2);
        System.out.println("¿Son iguales? " + c1.equals(c2));
        

       
       
//       
//        System.out.println(l1);                
//        System.out.println(l2);                
    }
    
}
