/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hoja_libre;

/**
 *
 * @author nelson
 */
public class Punto {
    int x, y;

    public Punto(int x, int y) {
        this.x = x;
        this.y = y;
    }
    
    public double distancia(Punto otroPunto){
        double calculo= Math.sqrt(Math.pow((otroPunto.x - x) , 2) + Math
                .pow((otroPunto.y - y), 2)); //
                 
        return calculo;
    }
}
