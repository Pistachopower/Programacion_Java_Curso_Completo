package persona_teoria;

/**
 *
 * @author nelson //
 */
public class Empleado extends Persona {

    double salario;

    //constructor sin super
//    public Empleado(String nombre, int edad, double estatura, double salario) {
//        this.nombre = nombre;
//        this.edad = edad;
//        this.estatura = estatura;
//        this.salario = salario;
//
//    }
    //cuando se tiene un constructor en la clase padre
    public Empleado(String nombre, int edad, double estatura, double salario) {
        super(nombre, edad, estatura);
        this.salario = salario;
    }

    //ejemplo de overriding
    @Override
    public String toString() {
        String cad = "Persona: " + "nombre=" + this.nombre + ", edad=" + this.edad + ", estatura=" + this.estatura;

        return cad;
    }

}
