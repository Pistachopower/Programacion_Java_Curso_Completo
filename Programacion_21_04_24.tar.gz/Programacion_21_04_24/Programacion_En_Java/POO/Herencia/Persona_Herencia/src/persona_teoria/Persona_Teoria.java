package persona_teoria;

public class Persona_Teoria {

    public static void main(String[] args) {
        //crear un objeto
        //Persona persona1 = new Persona("Nelson", 30, 1.78);
        //persona1.hoyEs(5);
        //persona1.mostrar_Atributos();
        
//        Persona p;
//        
//        p=  new Persona("sami", 25, 170);
//        p.mostrar_Atributos();
//        
//        p = new Empleado("Mario", 30, 160, 1500);
//        
//        p.mostrar_Atributos();
//        
//        p= new Cliente("Juan", 50, 200);
//        
//        p.mostrar_Atributos();
        
        
        Empleado e1= new Empleado("Samuel", 25, 170, 2500);
        Empleado e2= new Empleado("Samuel", 25, 170, 2500);
        
       
        
        System.out.println(e1.equals(e2));
        
       
        
        //p.mostrar_Atributos();
        
        //p.mostrar_Atributos();
        
        
        Object a= 5.5;
        
        //System.out.println(a.getClass().getName());
//System.out.println(a.getSuperclass());
    }
    

}
