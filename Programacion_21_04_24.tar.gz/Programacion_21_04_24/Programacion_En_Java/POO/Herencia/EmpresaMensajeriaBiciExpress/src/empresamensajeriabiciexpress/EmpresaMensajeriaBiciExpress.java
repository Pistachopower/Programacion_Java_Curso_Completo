/*
La empresa de mensajeria BiciExpress, que reparte
en bicicleta para disminuir el peso que tranportan
sus empleados solo utiliza cajas de carton. El 
volumen de estas se calcula como el 80 % del volumen
real, con el fin de evitar que se deformen y se rompan.
Otra caracteristica de las cajas de carton es que sus 
medidas siempre están en centimetros. 
Por último, la empresa para controlar costes, necesita
saber cuaĺ es la superficie total de  carton utilizado 
para construir todas las cajas. 

Escribe la clase CajaCarton heredando de la clase Caja


private static double superficieTotal = 0;

    public CajaCarton(int ancho, int alto, int fondo, String etiqueta) {
        super(ancho, alto, fondo, Unidad.CM);
        setEtiqueta(etiqueta);
        superficieTotal += 2 * (ancho * alto + alto * fondo + ancho * fondo) / 10000.0; // Convertir cm^2 a m^2
    }

    @Override
    public double getVolumen() {
        double volumenReal = super.getVolumen();
        return volumenReal * 0.8; // El volumen se calcula como el 80% del volumen real
    }

    public static double getSuperficieTotal() {
        return superficieTotal;
    }

    @Override
    public String toString() {
        return "CajaCarton{" +
                "ancho=" + this.ANCHO +
                ", alto=" + this.ALTO +
                ", fondo=" + this.FONDO +
                ", unidad=" + unidad +
                ", etiqueta='" + etiqueta + '\'' +
                ", volumen=" + getVolumen() +
                '}';
    }


 */
package empresamensajeriabiciexpress;

public class EmpresaMensajeriaBiciExpress {

    public static void main(String[] args) {
        CajaCarton c1= new CajaCarton(2, 2, 2, Unidad.CM);
        
        c1.getVolumen();
        
        //System.out.println(c1.getVolumen());
    }
    
}
