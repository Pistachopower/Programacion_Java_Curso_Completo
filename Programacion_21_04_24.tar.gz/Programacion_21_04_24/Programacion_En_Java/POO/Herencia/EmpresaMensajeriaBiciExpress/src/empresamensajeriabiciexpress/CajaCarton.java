/*
Supongamos que una caja rectangular tiene un largo (L), un ancho (W) y una altura (H). 
Entonces, las áreas de sus caras son:

    Cara frontal y trasera: L * H
    Caras laterales (x2): W * H
    Caras superiores e inferiores: L * W

Entonces, la superficie total (S) se puede calcular sumando estas áreas:

S=2(L∗H)+2(W∗H)+2(L∗W)S=2(L∗H)+2(W∗H)+2(L∗W)
 */
package empresamensajeriabiciexpress;

/**
 *
 * @author nelson
 */
public class CajaCarton extends Caja {
    
    public CajaCarton(int ANCHO, int ALTO, int FONDO, Unidad uni) {
        super(ANCHO, ALTO, FONDO, uni);
        
    }

    @Override
    public double getVolumen() {
        double volumenR= super.getVolumen();
        return volumenR  * 0.8;
    }
    
    @Override
    public String toString() {
        String c = "ANCHO=" + ANCHO + ", ALTO=" + ALTO + ", FONDO=" + FONDO + ", unidad=" + unidad
                + " etiqueta=" + this.etiqueta + " Volumen=" + getVolumen();
        return c;
    }
    


}
