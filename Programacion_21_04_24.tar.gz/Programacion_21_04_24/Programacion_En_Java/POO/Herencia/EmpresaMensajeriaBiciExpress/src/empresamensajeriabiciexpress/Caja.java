/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package empresamensajeriabiciexpress;

/**
 *
 * @author nelson
 */
public class Caja {

    protected final int ANCHO;
    protected final int ALTO;
    protected final int FONDO;
    protected String etiqueta;
    Unidad unidad;

    public Caja(int ANCHO, int ALTO, int FONDO, Unidad uni) {
        this.ANCHO = ANCHO;
        this.ALTO = ALTO;
        this.FONDO = FONDO;
        this.unidad = uni;
    }

    public double getVolumen() {
        double anchoV = unidad == unidad.CM ? ANCHO / 100.0 : ANCHO;
        double altoV = unidad == unidad.CM ? ALTO / 100.0 : ALTO;
        double fondoV = unidad == unidad.CM ? FONDO / 100.0 : FONDO;

        return anchoV * altoV * fondoV;
    }

    void setEtiqueta(String et) {

        if (et.length() > 30) {
            System.out.println("No es posible agregar etiqueta");

        } else {
            this.etiqueta = et;
        }

    }

    @Override
    public String toString() {
        String c = "ANCHO=" + ANCHO + ", ALTO=" + ALTO + ", FONDO=" + FONDO + ", unidad=" + unidad
                + " etiqueta=" + this.etiqueta;
        return c;
    }

}
