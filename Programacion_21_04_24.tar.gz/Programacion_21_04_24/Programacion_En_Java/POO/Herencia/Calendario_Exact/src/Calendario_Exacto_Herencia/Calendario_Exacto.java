package Calendario_Exacto_Herencia;

public class Calendario_Exacto extends Calendario {
    protected int hora;
    protected int minutos;
    protected int segundos;
    
    public Calendario_Exacto(int d, int m, int a, int h, int min, int s) {
        super(d, m, a);
        hora= h;
        minutos= min;
        segundos= s;
    }

    @Override
    public String toString() {
        return "Calendario: " + "año=" + super.a + ", mes=" + super.m;
    }

}
