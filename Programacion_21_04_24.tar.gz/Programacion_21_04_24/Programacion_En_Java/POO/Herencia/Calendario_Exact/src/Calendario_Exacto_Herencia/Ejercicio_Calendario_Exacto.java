/*
A partir de la clase calendario (examen), escribir la 
clase calendario exacto 
que detemina un instante de tiempo exacto formado por un 
año, mes, dia, minutos, segundos

implementar los metodos toString, equals y aquellos 
necesaios para manejar la clase
(incrementar hora, minuto)



 */
package Calendario_Exacto_Herencia;

public class Ejercicio_Calendario_Exacto {

    public static void main(String[] args) {
        Calendario c= new Calendario(5, 10, 2005);
        
        Calendario_Exacto c_E= new Calendario_Exacto(15, 2, 2005, 3, 25,35);
        
        System.out.println(c_E);        
    }
    
}
