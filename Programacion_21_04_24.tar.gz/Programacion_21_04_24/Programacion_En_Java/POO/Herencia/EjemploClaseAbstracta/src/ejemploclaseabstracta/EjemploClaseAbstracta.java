/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemploclaseabstracta;

public class EjemploClaseAbstracta {


    
    public static void main(String[] args) {
        B ob= new B();
        
        C ob2= new C();
        
        System.out.println(ob.a1);
        
        
    }
    
}
