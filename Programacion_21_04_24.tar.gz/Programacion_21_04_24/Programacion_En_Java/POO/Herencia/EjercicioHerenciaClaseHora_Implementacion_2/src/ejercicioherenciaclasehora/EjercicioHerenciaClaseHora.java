/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicioherenciaclasehora;

import java.util.Scanner;

/**
 *
 * @author martarobina
 */

/* Diseñar la clase Hora, que representa un instante de tiempo compuesto por la hora (de 0 a 23), y los minutos (de 0 a 59). Dispone de los métodos:
- Hora(hora,minuto), que construye un objeto con los datos pasados como parámetros, si estos datos son correctos. En caso contrario, se pondrá el atributo correspondiente a 0 y se mostrará un mensaje indicando el error.
- void inc(), que incrementa la hora en un minuto.
- boolean setMinutos(valor), que asigna un valor, si es válido, a los minutos. Devuelve true o false según haya sido posible modificar los minutos o no.
- boolean setHora(valor), que asigna un valor, si es válido, a la hora. Devuelve true o false según haya sido posible modificar la hora o no.
- String toString(), que devuelve una cadena con la representación de la hora, con la forma hora:minuto (no hace falta añadir 0 a la izquierda para valores menores que 10).
 */
public class EjercicioHerenciaClaseHora {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Hora r = new Hora(11, 30); //las 11:30
        System.out.println(r);
        for (int i = 1; i <= 61; i++) { //incrementamos 61 minutos
            r.inc();
        }
        System.out.println(r); //mostramos
        System.out.println("Escriba una hora:");
        int hora = new Scanner(System.in).nextInt();
        boolean cambio = r.setHora(hora); //cambiamos la hora
        if (cambio) {
            System.out.println(r);
        } else {
            System.out.println("La hora no se pudo cambiar");
        }
    }

}
