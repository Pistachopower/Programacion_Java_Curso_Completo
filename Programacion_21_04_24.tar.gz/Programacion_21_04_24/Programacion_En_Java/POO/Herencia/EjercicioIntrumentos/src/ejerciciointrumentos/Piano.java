/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciointrumentos;

/**
 *
 * @author martarobina
 */
public class Piano extends Instrumento{
    public Piano() {
        super(); 
    }

    @Override 
    public void interpretar() {
        for (Nota nota : melodia) {
            switch (nota) {
                case DO:
                    System.out.print("doooo ");
                    break;
                case RE:
                    System.out.print("reeee ");
                    break;
                case MI:
                    System.out.print("miiii ");
                    break;
                case FA:
                    System.out.print("faaaa ");
                    break;
                case SOL:
                    System.out.print("sollll ");
                    break;
                case LA:
                    System.out.print("laaaa ");
                    break;
                case SI:
                    System.out.print("siiii ");
                    break;
            }
        }
        System.out.println("");
    }
}
