/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package ejerciciointrumentos;

/**
 *
 * @author martarobina
 */
public enum Nota {
    DO, RE, MI, FA, SOL, LA, SI
}
