
package ejercicio_cuentacorriente.Externa;

import ejercicio_cuentacorriente.CuentaCorriente;





public class CuentaCorrienteExterna {
     
    
}
