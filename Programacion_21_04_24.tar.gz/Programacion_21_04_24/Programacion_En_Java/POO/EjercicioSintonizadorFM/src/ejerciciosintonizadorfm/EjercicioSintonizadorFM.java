/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejerciciosintonizadorfm;

/**
 *
 * @author marta
 */
/* Definir una clase que permita controlar un sintonizador digital de emisoras FM. 
Concretamente, se desea dotar al controlador de una interfaz que permita  
subir (up) o bajar (down) la frecuencia (único atributo), en saltos de 0,5MHz, 
y mostrar la frecuencia sintonizada cuando se desee (display). 
Supondremos que el rango de frecuencias para manejar oscila entre los 80MHz y 
los 108MHz y que, al inicio, el controlador sintonice la frecuencia indicada 
en el constructor (constructor 1) o 80MHz por defecto (constructor 2). 
En el constructor 1, controlaremos que la frecuencia indicada esté dentro de los márgenes válidos, 
limitando su valor al valor límite más cercano en caso contrario (por ejemplo, 
70MHz pasaría a ser 80MHZ). Si durante una operación de subida o bajada se sobrepasa 
uno de los dos límites, la frecuencia sintonizada debe pasar a ser la del extremo contrario. 
Escribir un pequeño programa principal para probar su funcionamiento.
 */
public class EjercicioSintonizadorFM {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SintonizadorFM a, b;

        a = new SintonizadorFM(107);
        a.up();
        a.up();
        a.up();
        a.up();
        a.display();

        b = new SintonizadorFM(80.5);
        b.down();
        b.down();
        b.down();
        b.display();

        a = new SintonizadorFM(200);
        a.display();
    }

}
