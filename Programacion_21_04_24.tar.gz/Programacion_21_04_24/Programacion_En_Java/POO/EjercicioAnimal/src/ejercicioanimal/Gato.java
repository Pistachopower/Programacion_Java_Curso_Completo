/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioanimal;

/**
 *
 * @author nelson
 */
public class Gato extends Animal{
    String color;
    
    public Gato(String nombre, int edad, String color) {
        super(nombre, edad);
        this.color= color;
    }
    
}
