package ejercicio_cuentacorriente;

public class CuentaCorriente {

    String dni;
    String nombreTitular;
    double saldo;

    //constructur inicial
    CuentaCorriente(String dni, String nombreTitular) {
        this.dni = dni;
        this.nombreTitular = nombreTitular;
        saldo= 0;
    }

    CuentaCorriente(String dni,  double saldo) {
        this.dni= dni;
        this.saldo= saldo;
    }
    
    
    
    CuentaCorriente(String dni,  String nombreTitular, double saldo) {
        this(dni, nombreTitular);
        this.saldo= saldo;
        
    }
    
    
    
    
    
    
    
    
    
    //metodo incrementar saldo
    void ingresarSaldo(double saldo) {
        this.saldo= this.saldo + saldo;
    }
    
    //metodo mostrarInformacion
    void mostrarInformacion() {
        System.out.println("Nombre: " + nombreTitular + " , DNI: " + dni + " , saldo: " + saldo);
         
    }

    boolean sacarDinero(double cantidad) {
        boolean operacion = false;

        //si saldo es mayor o igual a cantidad se puede sacar dinero y retornamos true para indicar que la operacion se ha realizado
        if (this.saldo >= cantidad) {
            //restamos el saldo
            this.saldo = this.saldo - cantidad;

            operacion = true;

            //devolvemos true para indicar que la operacion se ha realizado
            return operacion;

            //en caso contrario devolvemos false ya que no se pudo realizar nada    
        } else {
            return operacion;

        }

    }

}
