package ejercicio_cuentacorriente;
import ejercicio_cuentacorriente.Externa.CuentaCorrienteExterna;
/*
Modificar la visibilidad de la clase cuenta corriente para que sea visible 
desde clases externas. Modificar la visibilidad de sus atributos para que 
saldo, no sea visible para otras clases, nombre sea visible para cualquier 
clase, dni solo sea visible por clases vecinas. Realizar un programa 
para ver la visibilidad (desde el main) 

*/


public class Ejercicio_CuentaCorriente {

    public static void main(String[] args) {
        CuentaCorriente c1 = new CuentaCorriente("7777", 800);
        
        CuentaCorrienteExterna c2= new CuentaCorrienteExterna("carolina", "sevilla");
        
        //no aparece en la clase vecina al estar publico
        //System.out.println(c1.saldo);
         
        //visibilidad de dni clase vecina
        //System.out.println(c1.dni);
        
        //System.out.println(c1.nombreTitular);
        
        System.out.println(c2.gestor);
        
        
        
    
    }
    
}
