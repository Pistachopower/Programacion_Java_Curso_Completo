/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejerciciometodoinsertarfinalmain;

import java.util.Arrays;

/**
 *
 * @author martarobina
 */

/* Implementar el método no estático
void insertarFinal (int nuevo)
que inserta un número entero al final de tablaEnteros[ ], que es un atributo no estático de la clase principal (en la que se encuentra el main). Escribir un programa que inicialice la tabla con los números del 1 al 10 y después la muestre por consola.
*/

public class ClasePrincipal {

    /**
     * @param args the command line arguments
     */
    int[] tablaEnteros = new int[0];

    public static void main(String[] args) {
        ClasePrincipal m = new ClasePrincipal();
        for (int i = 0; i < 10; i++) {
            m.insertarFinal(i + 1);
        }
        System.out.println("tabla: " + Arrays.toString(m.tablaEnteros));
    }

    void insertarFinal(int nuevo) {
        tablaEnteros = Arrays.copyOf(tablaEnteros, tablaEnteros.length + 1);
        tablaEnteros[tablaEnteros.length - 1] = nuevo;
    }

}
