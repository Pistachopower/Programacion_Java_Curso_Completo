
package ejercicioalumnodao1;


import java.sql.Connection;
import java.util.Date;

public class EjercicioAlumnoDAO1 {
/*
    Alumno a;  
        
        Date hoy = new Date();
        System.out.println(hoy);
        
        a = new Alumno(990, "Ana", hoy, 6.7, "1A");
        AlumnoDAO.create(a);
        a = new Alumno(991, "Juan", hoy, 7.8, "2A");
        AlumnoDAO.create(a);
        a = new Alumno(992, "Luis", hoy, 8.9, "1B");
        AlumnoDAO.create(a);
        
        
        a = AlumnoDAO.read(991);
        System.out.println(a);
        
        a = AlumnoDAO.read(990);
        System.out.println(a);
        
        a.setNombre("Ana María Pérez García");
        a.setNotaMedia(10.0);
        AlumnoDAO.update(a);
        
        AlumnoDAO.delete(992);
    */

    
    public static void main(String[] args) {
       Alumno a;  
        
        Date hoy = new Date();
        System.out.println(hoy);
//        
        a = new Alumno(99, "suela", hoy, 6.7, "1A");
        AlumnoDAO.create(a);
        
      

        
        
//        a = new Alumno(991, "Juan", hoy, 7.8, "2A");
//        AlumnoDAO.create(a);
//        a = new Alumno(992, "Luis", hoy, 8.9, "1B");
//        AlumnoDAO.create(a);
//        
//        
//        a = AlumnoDAO.read(99);
//        System.out.println(a);
        
//        a = AlumnoDAO.read(990);
//        System.out.println(a);
//        
//        a.setNombre("Ana María Pérez García");
//       a.setNotaMedia(10.0);

        System.out.println(a);


       AlumnoDAO.update(a);
//        
//        AlumnoDAO.delete(992);ç
    
    }
    
}
