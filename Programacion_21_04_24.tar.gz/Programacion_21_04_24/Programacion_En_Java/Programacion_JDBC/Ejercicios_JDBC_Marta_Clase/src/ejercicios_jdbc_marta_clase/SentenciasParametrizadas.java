package ejercicios_jdbc_marta_clase;

import java.sql.*;

public class SentenciasParametrizadas {

    public static void main(String[] args) {
        
        // Mostrar todos los alumnos de un curso cuya nota es mayor que cierta nota de corte, 
        // la nota y el curso se reciben por teclado.
        /*Connection con;
        PreparedStatement sentencia;
        String sql;

        String url = "jdbc:mysql://localhost/instituto1DAW";
        try {
            con = DriverManager.getConnection(url, "root", "1234");
            sql = "SELECT nombre, media FROM alumnos WHERE curso = ? AND media > ?";
            
            sentencia = con.prepareStatement(sql);
            
            System.out.println("Curso:");
            String curso = new Scanner(System.in).nextLine();

            System.out.println("Nota de corte:");
            Double notaCorte = new Scanner(System.in).nextDouble();
            
            sentencia.setString(1, curso); 
            sentencia.setDouble(2, notaCorte); 
            
            ResultSet rs = sentencia.executeQuery();
            
            while(rs.next()) {
                System.out.println(rs.getString("nombre") + "\t" + rs.getDouble("media"));
            }
            
            con.close(); //cerramos la conexión
        } catch (SQLException ex) {
            System.out.println("Ha ocurrido algún error.");
        }*/
        
        // Informe de alumnos con Bien o Notable. Notas en orden ascendente.
        Connection con;

        String url = "jdbc:mysql://localhost/instituto1DAW";
        try {
            con = DriverManager.getConnection(url, "root", "1234");

            System.out.println("Alumnos con Bien:");
            alumnosXNota(con, 6, 7);
            System.out.println("\nAlumnos con Notable:");
            alumnosXNota(con, 7, 9);

            con.close(); 
        } catch (SQLException ex) {
            System.out.println("Ha ocurrido algún error.");
        }
        
        
        
        

    }

    static public void alumnosXNota(Connection con, double n1, double n2) throws SQLException {
        String sql = "SELECT nombre, media FROM alumnos WHERE ? <= media AND media < ? ORDER BY media ASC";

        PreparedStatement sentencia = con.prepareStatement(sql);

        sentencia.setDouble(1, n1);
        sentencia.setDouble(2, n2);

        ResultSet rs = sentencia.executeQuery();

        while (rs.next()) {
            System.out.println(rs.getString("nombre") + "\t\t" + rs.getDouble("media"));
        }
    }

}
