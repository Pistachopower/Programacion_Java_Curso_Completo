/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package empresa;


import java.sql.*;
/**
 *
 * @author nelson
 */
public class empleadoDAO {
    
    	private Connection conexion;
	private final String USUARIO="root";
	private final String PASSWORD="1234";
	private final String MAQUINA = "localhost";
	private final String BD = "empresa";

    public empleadoDAO() {
        conexion= conectar();
    }

        
        
        
    
    public Connection conectar() {
        Connection con= null;
        
        String url = "jdbc:mysql://" + MAQUINA + "/" + BD;

        try {
            con = DriverManager.getConnection(url, USUARIO, PASSWORD);

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
        return con;
    
    }
    
    public void desconectar() {
        try {
            conexion.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    
    }
    
    //insertamos el objeto en la bd
    public void create (empleado empleado) {
        //si empleado es vacio no hacemos ninguna insercion
        if (empleado != null) {
            
            //hacemos el insert
            String sql = "INSERT INTO empleados (numemp, nombre, edad, oficina_FK, puesto, contrato) "
                    + "VALUES ( ?, ?, ?, ?, ?,  ?);";

            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                
                sentencia.setInt(1, empleado.id);
                sentencia.setString(2, empleado.nombre);
                sentencia.setInt(3, empleado.edad);
                sentencia.setInt(4, empleado.oficina);
                sentencia.setString(5, empleado.puesto);
                sentencia.setDate(6, empleado.fecha);
                
                sentencia.executeUpdate();
                
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
            

            
        }
    
    
    }
    
    public void delete(int id) {
        
        
        String sql = "DELETE FROM empleados "+ "WHERE numemp= ?";
        
        try {
           PreparedStatement sentencia = conexion.prepareStatement(sql);
            
            
            
            sentencia.setInt(1, id);
            
            sentencia.executeUpdate();
            

            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    
    }

    
    
    
}
