/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package empresa;

import java.sql.*;

/**
 *
 * @author nelson
 */
public class OficinaDAO {

    Connection conexion;
    private final String USUARIO = "root";
    private final String PASSWORD = "1234";
    private final String MAQUINA = "localhost";
    private final String BD = "empresa";

    public OficinaDAO() {
        this.conexion = conectar();
    }

    private Connection conectar() {
        Connection con = null;

        String url = "jdbc:mysql://" + MAQUINA + "/" + BD;

        try {
            con = DriverManager.getConnection(url, USUARIO, PASSWORD);

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return con;

    }

    public void desconectar() {

        try {
            conexion.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }
    
        public void create(Oficina oficina) {
        if (oficina != null) {
            String sql = "INSERT INTO Oficinas (oficina, ciudad, extension, ventas) "
                    + "VALUES ( ?,    ?,     ?,     ?  )";

            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setInt(1, oficina.getOficina());
                sentencia.setString(2, oficina.getCiudad());
                sentencia.setDouble(3, oficina.getExtension());
                sentencia.setDouble(4, oficina.getVentas());
                

                sentencia.executeUpdate();
            } catch (SQLException ex) {
                System.out.println("Error al insertar.");
            }
        }
    }
    
    
    public  void update(Oficina oficina) {
        //hay valores en el objeto
        if (oficina != null) {
            
            String sql = "UPDATE Oficinas "
                	+ "SET ciudad=?, ventas=? "
                	+ "WHERE oficina = ?";
            try {
                //preparamos la sentencia
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                
                //seleccionamos los atributos del objeto 
                sentencia.setString(1, oficina.getCiudad());
                sentencia.setDouble(2, oficina.getVentas() + 100);
                sentencia.setDouble(3, oficina.getOficina());
                
                sentencia.executeUpdate();
                
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }

            
        }
    
    
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public Oficina read(String nombre) {
         Oficina oficina = null;
         
         String sql = "SELECT * "+ "FROM Oficinas " + " where ciudad= ?";
         
         try {
             PreparedStatement sentencia = conexion.prepareStatement(sql);
             
             sentencia.setString(1, nombre);
             
             ResultSet rs = sentencia.executeQuery();


             while (rs.next()) {                 
                 int numOficina= rs.getInt("oficina");
                 String ciudad= rs.getString("ciudad");
                 double extension= rs.getDouble("extension");
                 double ventas= rs.getDouble("ventas");
                 
                 System.out.println(numOficina + " "+ ciudad +" "+ extension + " " + ventas);

                 
             }
            
        } catch (SQLException ex) {
             System.out.println(ex.getMessage());
        }

         
         
         return oficina;
        
    }

}
