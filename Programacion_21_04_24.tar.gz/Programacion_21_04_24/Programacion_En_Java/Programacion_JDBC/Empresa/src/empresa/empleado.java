
package empresa;

import java.sql.Date;

/**
 *
 * @author nelson
 */
public class empleado {
    int id;
    String nombre;
    int edad;
    int oficina;
    Date fecha;
    String puesto;

    public empleado(int id, String nombre, int edad, int oficina, Date fecha, String puesto) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
        this.oficina = oficina;
        this.fecha = fecha;
        this.puesto = puesto;
    }

    @Override
    public String toString() {
        return "empleado{" + "id=" + id + ", nombre=" + nombre + ", edad=" + edad + ", oficina=" + oficina + ", fecha=" + fecha + ", puesto=" + puesto + '}';
    }
    
    
}
