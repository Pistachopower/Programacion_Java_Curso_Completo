/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package empresa;

/**
 *
 * @author nelson
 */
public class Oficina {
    private int oficina;
    private String ciudad;
    private double extension;
    private double ventas;

    public Oficina(int oficina, String ciudad, double extension, double ventas) {
        this.oficina = oficina;
        this.ciudad = ciudad;
        this.extension = extension;
        this.ventas = ventas;
    }

    public int getOficina() {
        return oficina;
    }

    public void setOficina(int oficina) {
        this.oficina = oficina;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public double getExtension() {
        return extension;
    }

    public void setExtension(double extension) {
        this.extension = extension;
    }

    public double getVentas() {
        return ventas;
    }

    public void setVentas(double ventas) {
        this.ventas = ventas;
    }
    
    

    @Override
    public String toString() {
        return "Oficina{" + "oficina=" + oficina + ", ciudad=" + ciudad + ", extension=" + extension + ", ventas=" + ventas + '}';
    }
    
    
}
