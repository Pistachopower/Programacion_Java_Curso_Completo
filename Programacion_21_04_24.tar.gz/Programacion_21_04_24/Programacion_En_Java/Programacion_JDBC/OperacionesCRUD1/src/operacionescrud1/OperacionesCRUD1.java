
package operacionescrud1;

import java.sql.Connection;
import java.util.Date;
/*
        Alumno a;
        Date hoy = new Date();
        System.out.println(hoy);
        
        a = new Alumno(990, "Ana", hoy, 6.7, "1A");
        a.create();
        a = new Alumno(991, "Juan", hoy, 7.8, "2A");
        a.create();
        a = new Alumno(992, "Luis", hoy, 8.9, "1B");
        a.create();
        
        
        a = Alumno.read(991);
        System.out.println(a);
        
        a = new Alumno(990);
        a.read();
        System.out.println(a);
        
        a.setNombre("Ana María Pérez García");
        a.setNotaMedia(10.0);
        a.update();
        
        a = Alumno.read(992);
        a.delete();


*/
public class OperacionesCRUD1 {

    public static void main(String[] args) {
        Alumno a;
        Date hoy = new Date();
        
        a = new Alumno(990, "Ana", hoy, 6.7, "1A");
        
        //a.create();
        
        //Alumno b= Alumno.read(990);
        
        
        a.delete();
        
        

    }
    
}
