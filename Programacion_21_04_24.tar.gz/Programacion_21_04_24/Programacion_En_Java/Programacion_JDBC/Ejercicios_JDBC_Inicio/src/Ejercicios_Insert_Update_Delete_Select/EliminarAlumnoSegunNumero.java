/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios_Insert_Update_Delete_Select;

import java.sql.*;
import java.util.Scanner;

public class EliminarAlumnoSegunNumero {

    public static void main(String[] args) {
        Connection con;

        Statement sentencia;

        String sql;

        String url = "jdbc:mysql://localhost/instituto1DAW";

        try {

            con = DriverManager.getConnection(url, "root", "1234"); // Poner el nombre de vuestra base de datos

            sentencia = con.createStatement();

            System.out.println("Número de alumno:");

            int num = new Scanner(System.in).nextInt();

            sql = "DELETE FROM alumnos " // Poner el nombre de vuestra tabla

                    + "WHERE numero = " + num;

            sentencia.executeUpdate(sql);

            System.out.println("Se ha eliminado el alumno con número: " + num);

            con.close(); //cerramos la conexión

        } catch (SQLException ex) {

            System.out.println("Ha ocurrido algún error.");

        }
    }
}
