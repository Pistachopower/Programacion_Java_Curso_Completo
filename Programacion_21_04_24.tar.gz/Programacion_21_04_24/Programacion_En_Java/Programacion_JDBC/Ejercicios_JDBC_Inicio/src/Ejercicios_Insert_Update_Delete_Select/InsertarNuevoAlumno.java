/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios_Insert_Update_Delete_Select;
import java.sql.*;

import java.util.Locale;

import java.util.Scanner;

public class InsertarNuevoAlumno {
        // Solicitar los datos de un nuevo alumno e insertarlo en la base de datos

    public static void main(String[] args) {
         Connection con;

        Statement sentencia;

        String sql;



        //String url = "jdbc:mysql://localhost/Instituto1DAW";    // Poner el nombre de vuestra base de datos
        String url = "jdbc:mysql://localhost/instituto1DAW";

        try {

            con = DriverManager.getConnection(url, "root", "1234");

            sentencia = con.createStatement();

            System.out.println("Número de alumno:");

            int num = new Scanner(System.in).nextInt();

            System.out.println("Nombre:");

            String nombre = new Scanner(System.in).nextLine();

            System.out.println("Fecha de nacimiento");

            String fnac = new Scanner(System.in).nextLine();

            System.out.println("Media:");

            Double media = new Scanner(System.in).useLocale(Locale.US).nextDouble();

            System.out.println("Curso:");

            String curso = new Scanner(System.in).nextLine();



             sql=  "INSERT INTO alumnos (numero, nombre, curso, notaMedia, fechaNac) VALUES (" + num + 
                     ",'" + nombre + "', '" + curso + " ', " + media + ", ' " +  fnac + " ')";

            sentencia.executeUpdate(sql);

            con.close(); //cerramos la conexión

            System.out.println("Se ha insertado el nuevo alumno.");

        } catch (SQLException ex) {

            System.out.println("Ha ocurrido algún error.");

        }

    }
    
}
