package Ejercicios_Insert_Update_Delete_Select;

import java.sql.*; //debes importar este paquete para hacer la conexion con el sgbd
import java.util.Scanner;

public class Ejercicio2_ResultSet {

    /*
Modificar el ejercicio anterior para que los alumnos se
muestren en orden inverso.   
    
     */
    public static void main(String[] args) {
        //inicializamos los objetos para conectar la bd, generar las consulta
        Connection con;
        Statement sentencia;
        ResultSet rS;
        String sql;
        //sistemaGestorBD/BD/ localhost/nombreDeBD
        String url = "jdbc:mysql://localhost/instituto1DAW";
        Scanner teclado = new Scanner(System.in);

        try {
            con = DriverManager.getConnection(url, "root", "1234");

            //primer param: aqui estas diciendo que puedes leer de cualquier manera, 
            //segundo param: solamente lectura de la tabla
            sentencia = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);

            System.out.println("Introduce el curso: ");
            String curso = teclado.nextLine();

            //generamos la consulta
            /*
                        sql = "SELECT nombre, fnac FROM Alumnos "

                    + "WHERE curso = '" + curso +"'" ;

            rs = sentencia.executeQuery(sql);

             */
            sql = "select nombre, fechaNac from alumnos where curso=" + " '" + curso + "';";

            rS = sentencia.executeQuery(sql);

            rS.afterLast(); //colocamos el cursor detras de la ultima fila
            
            
            /*
            El método previous() en un ResultSet de Java se utiliza para mover 
            el cursor hacia atrás en el conjunto de resultados. Esto significa 
            que, en lugar de avanzar a la siguiente fila como lo hace next(), 
            previous() mueve el cursor a la fila anterior en el conjunto de 
            resultados.
            */

            while (rS.previous()) {

                String nombre = rS.getString("nombre");

                Date fecha = rS.getDate("fechaNac");

                System.out.println("Alumno: " + nombre + "\tF. nacimiento: " + fecha);

            }

            con.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
