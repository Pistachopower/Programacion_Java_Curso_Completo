
package Ejercicios_Insert_Update_Delete_Select;
import java.sql.*; //debes importar este paquete para hacer la conexion con el sgbd
/*
Mostrar el nombre y nota de todos los alumnos y, a posteriori, mostrar el alumno con la
mejor nota media y al alumno con la peor nota media. Supondremos que no existen
alumnos con notas repetidas.
Pista: si ordenamos los alumnos por su nota en orden decreciente, el primer alumno de
la tabla resultante será el que mejor nota tiene, y el último será el de la nota más baja.

*/
public class Ejercicio3_ResultSet {
    public static void main(String[] args) {
                //inicializamos los objetos para conectar la bd, generar las consulta
        Connection con;
        Statement sentencia;
        ResultSet rS;
        String sql;
        //sistemaGestorBD/BD/ localhost/nombreDeBD
        String url = "jdbc:mysql://localhost/instituto1DAW";
        
        try {
            con = DriverManager.getConnection(url, "root", "1234");
            
            //primer param: aqui estas diciendo que puedes leer de cualquier manera, 
            //segundo param: solamente lectura de la tabla
            sentencia = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            
            //vamos a consultar todos los alumnos ordenados por su nota
            sql= "select nombre, notaMedia from alumnos order by notaMedia Desc;";
            
            rS= sentencia.executeQuery(sql);
            
            
         
            while (rS.next()) {                
                System.out.println(rS.getString(1) + " - " + rS.getDouble(2));
            }
            
            /*
            El alumno con la mejor nota estará en la primera fila
            y el alumno con la peor nota media mas baja estara en la ultima fila
            */
            if (rS.first()) { //si nos podemos colocar en la primera fila
                String nombre= rS.getString("nombre");
                Double media= rS.getDouble("notaMedia");
                
                System.out.println("Nota más alta: " + nombre + " " + media);
                
            }
            if (rS.last()) { //si nos podemos colocar en la primera fila
                String nombre= rS.getString("nombre");
                Double media= rS.getDouble("notaMedia");
                
                System.out.println("Nota más baja: " + nombre + " " + media);
                
            }
            
            con.close();
        } catch (SQLException e) {
             System.out.println(e.getMessage());
        }
    }
}
