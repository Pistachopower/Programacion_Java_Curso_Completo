/*
        System.out.println("Introduce el id: ");
        int numero = teclado.nextInt();
//        //teclado.nextLine();
//        System.out.println("Introduce el nombre: ");
//        String nombre = teclado.next();
//
//        System.out.println("Introduce el curso: ");
//        String curso = teclado.next();
//        
//        System.out.println("Introduce la nota: ");
//        double notaMedia = teclado.nextDouble();
//
//        System.out.println("Introduce la nota: ");
//        System.out.println("YYYY-MM-DD");
//        String fechaNac = teclado.next();


//             sql=  "INSERT INTO alumnos (numero, nombre, curso, notaMedia, fechaNac) VALUES (" + numero + 
//                     ",'" + nombre + "', '" + curso + " ', " + notaMedia + ", ' " +  fechaNac + " ')";

           
            //sql= "UPDATE alumnos SET notaMedia= notaMedia + 1 WHERE curso='1b';";
           //sql= "UPDATE alumnos set notaMedia= notaMedia + 1" + " where curso= '1b'";
          
           
           //sql= "DELETE FROM alumnos where numero=" + numero ;

        //creamos los datos que se van a agregar
//        int numero = 4;
//        String nombre = "Manuel";
//        String curso = "1B";
//        double notaMedia = 6.5;
//        String fechaNac = "2000-04-19";

INSERTAR EN LA MISMA TABLA ALUMNOS DOS FILAS QUE TENGAN COMO CURSO 1B
Y DESPUES INCREMENTAMOS LA NOTA MEDIA A TODOS LOS ALUMNOS DEL CURSO 1B


Ejercicios pendiente
solicitar al usuario todos los datos suyos e introducirlos en la base de datos.        
Solicitar el numero de un alumno y eliminarlo de la base de datos.

 */
package Ejercicios_Insert_Update_Delete_Select;

import java.sql.*; //debes importar este paquete para hacer la conexion con el sgbd
import java.util.Locale;
import java.util.Scanner;

public class PruebaBD2 {

    public static void main(String[] args) {
        Connection con;
        Statement sentencia;
        String sql;
        //sistemaGestorBD/BD/ localhost/nombreDeBD
        String url = "jdbc:mysql://localhost/instituto1DAW";

        Scanner teclado = new Scanner(System.in);
        teclado.useLocale(Locale.US);

        //teclado.nextLine();
        try {
            con = DriverManager.getConnection(url, "root", "1234");
            sentencia = con.createStatement();

            //sql = "SELECT * FROM alumnos WHERE extract(YEAR from fechaNac)>2008;";
            sql = "select * from alumnos";

            ResultSet rS = sentencia.executeQuery(sql);
            //rS.next();
            //double mediaFila = rs.getDouble(2);
            //int id= rS.getInt("numero");
            //String nombre= rS.getString("nombre");
            // Date fecha= rS.getDate("fechaNac"); 
            while (rS.next()) {
                int id= rS.getInt("numero");
                String nombre= rS.getString("nombre");
                double mediaFila = rS.getDouble("notaMedia");
                 Date fecha= rS.getDate("fechaNac"); 
                 
                  
                  System.out.println(id);
                  System.out.println(nombre);
                  System.out.println(mediaFila);
                  System.out.println(fecha);
                 
            }

          
           

            con.close();
            //System.out.println("¡Has guardado los datos correctamente!");

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

}
