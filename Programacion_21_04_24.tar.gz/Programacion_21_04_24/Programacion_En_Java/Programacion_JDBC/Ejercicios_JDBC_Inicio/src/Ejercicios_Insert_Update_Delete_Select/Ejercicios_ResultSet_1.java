package Ejercicios_Insert_Update_Delete_Select;

import java.sql.*; //debes importar este paquete para hacer la conexion con el sgbd
import java.util.Scanner;

public class Ejercicios_ResultSet_1 {

    /*
    Mostrar el nombre y fecha de nacimiento de todos los
alumnos de un curso solicitado al usuario por teclado.

     */
    public static void main(String[] args) {
        //inicializamos los objetos para conectar la bd, generar las consulta
        Connection con;
        Statement sentencia;
        String sql;
        //sistemaGestorBD/BD/ localhost/nombreDeBD
        String url = "jdbc:mysql://localhost/instituto1DAW";
        Scanner teclado = new Scanner(System.in);

        try {
            con = DriverManager.getConnection(url, "root", "1234");
            sentencia = con.createStatement();

            System.out.println("Introduce el curso: ");
            String curso = teclado.nextLine();

            //generamos la consulta
            sql = "select nombre, fechaNac from alumnos where curso=" + " '" + curso + "';";
            
            //guardamos el envoltorio
            ResultSet rS = sentencia.executeQuery(sql);
            
            //recorremos las columnas
            while (rS.next()) {                
                //obtenemos el nombre y la fecha con los metodos
                String nombre= rS.getString("nombre");
                Date fecha= rS.getDate("fechaNac");
                
                System.out.println(nombre +  " " + fecha);
                
            }

            con.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
