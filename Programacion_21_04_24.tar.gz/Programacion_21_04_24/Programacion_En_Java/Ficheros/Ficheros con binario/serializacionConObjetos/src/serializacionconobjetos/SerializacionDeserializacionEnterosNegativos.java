package serializacionconobjetos;

import java.io.*;
import java.util.Scanner;

/*
Grabar en el fichero numeros.dat una serie de numeros enteros no
negativos, introducidos por teclado. La serie acabará cuando 
escribamos -1. Abrir de nuevo numeros.dat para lectura y 
leer todos los numeros hasta el final del fichero, mostrandolos
por pantalla y copiandolos en un segundo fichero numerosCopia.dat

 */
public class SerializacionDeserializacionEnterosNegativos {

//    public static void main(String [] args) {
//        System.out.println("hola");
//        
//    }
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        //escritura
        try (ObjectOutputStream flujoSalida = new ObjectOutputStream(new FileOutputStream("numeros.dat"))) {

            System.out.println("Introduce el entero: ");
            int numero = teclado.nextInt();

            while (numero >= 0) {
                flujoSalida.writeInt(numero);

                System.out.println("Introduce el entero: ");
                numero = teclado.nextInt();

            }

        } catch (IOException e) {
            System.out.println(e);
        }

        /*
        Abrimos flujo de entrada para leer los numeros grabados y de salida para grabarlos en el archivo copia
        */
        try (ObjectInputStream flujoEntrada = new ObjectInputStream(new FileInputStream("numeros.dat")); 
             ObjectOutputStream flujoSalida = new ObjectOutputStream(new FileOutputStream("numerosCopia.dat"))) {

            while (true) {
                int numero = flujoEntrada.readInt();
                System.out.println("Numero: " + numero);

                flujoSalida.writeInt(numero);

            }

        } catch (EOFException ex) {

            System.out.println("Fin fichero");
        } catch (Exception e) {
            System.out.println(e);
        }

    }
}
