package serializacionconobjetos;

import java.io.*;


/*
realizar otro ejemplo de serializacion pero 
con objeto tipo string

Recuperar el archivo binario y mostrar por consola

 */
public class SerializacionDeserializacionConCadenas {

    public static void main(String[] args) {
        String texto = "hola mundo \n como estas \n encantado de conocerte \n quiero ser el mejor programador";

        //escritura
        try (ObjectOutputStream flujosalida = new ObjectOutputStream(new FileOutputStream("string.dat"))) {

            flujosalida.writeObject(texto);

            // Código dentro del bloque try
        } catch (IOException e) {
            System.out.println(e);
        }
        
        //lectura
        try (ObjectInputStream flujoEntrada = new ObjectInputStream(new 			FileInputStream("string.dat"))) {
            String parrafo= (String) flujoEntrada.readObject();
            
            System.out.println(parrafo);  
            
        } catch (IOException e) {
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }

    }
}
