/*
escribir en un archivo datos.dat los valores de una tabla de diez enteros
 */
package hoja_libre;


import java.io.*; 

public class Hoja_Libre {

    public static void main(String[] args) {
       int listaNum[]= {2,3,5,6,7,8,9,10,11,12};
       
        try {
            //escritura
            FileOutputStream archivo= new FileOutputStream("enteros.dat");
            
            //constructor
            ObjectOutputStream out= new ObjectOutputStream(archivo);
            
            
        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
}
