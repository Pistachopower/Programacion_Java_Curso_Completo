/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosficherosbinarios;

/**
 *
 * @author martarobina
 */
import java.io.*;
import java.util.*;

/* Por motivos estadísticos, se desea llevar constancia del número de llamas recibidas cada día en una oficina.
Para ello, al terminar cada jornada laboral se guarda dicho número al final de un archivo binario.
Implementa una aplicación con un menú que nos permita añadir el número correspondiente cada día
y ver la lista completa en cualquier momento */

public class LlamadasOficina {

    public static void main(String[] args) {
        
        int num;
        try (ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream("llamadas.dat"))) {
            //gestión de lista de llamadas:
            int opcion;
            do {
                System.out.println("1. Añadir número de llamadas");
                System.out.println("2. Ver lista números de llamadas");
                System.out.println("3. Salir");
                System.out.print("\nIntroducir opción: ");
                opcion = new Scanner(System.in).nextInt();
                System.out.println("");
                if (opcion == 1) {
                    System.out.print("Nuevo número de llamadas: ");
                    num = new Scanner(System.in).nextInt();
                    out.writeInt(num);
                    out.flush();
                } else if (opcion == 2) {
                    try {
                        ObjectInputStream in = new ObjectInputStream(
                            new FileInputStream("llamadas.dat"));
                        while (true) {
                            num = in.readInt();
                            System.out.println(num);
                        }
                    } catch (EOFException e) {
                        System.out.println("No hay más llamadas");
                    } catch (IOException ex) {
                        System.out.println("Lista vacía");
                    }
                }
            } while (opcion != 3);
            // Al salir guardamos los datos:
        } catch (IOException ex) {
            System.out.println(ex);
        }
        // Otra forma: usando una tabla y recuperando al inicio la información guardada
        // Aunque debía hacerse como se solicitó en clase, guardando entero a entero
        /*int[] llamadas = new int[0];
        try ( ObjectInputStream in = new ObjectInputStream(
                new FileInputStream("llamadas.dat"))) {
            llamadas = (int[]) in.readObject();
        } catch (IOException ex) {
            System.out.println("lista vacía");
        } catch (ClassNotFoundException ex) {
            System.out.println(ex);
        }
        //gestión de lista de llamadas:
        int opcion;
        do {
            System.out.println("1. Añadir número de llamadas");
            System.out.println("2. Ver lista números de llamadas");
            System.out.println("3. Salir");
            System.out.print("\nIntroducir opción: ");
            opcion = new Scanner(System.in).nextInt();
            System.out.println("");
            if (opcion == 1) {
                System.out.print("Nuevo número de llamadas: ");
                int num = new Scanner(System.in).nextInt();
                llamadas = Arrays.copyOf(llamadas, llamadas.length + 1);
                llamadas[llamadas.length - 1] = num;
            } else if (opcion == 2) {
                System.out.println(Arrays.toString(llamadas));
            }
        } while (opcion != 3);
        // Al salir guardamos los datos:
        try ( ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream("llamadas.dat"))) {
            out.writeObject(llamadas);
        } catch (IOException ex) {
            System.out.println(ex);
        }*/
    }

}
