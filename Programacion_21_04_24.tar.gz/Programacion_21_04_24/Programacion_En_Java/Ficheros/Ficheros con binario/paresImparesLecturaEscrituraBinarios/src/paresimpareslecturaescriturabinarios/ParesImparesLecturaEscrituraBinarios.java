package paresimpareslecturaescriturabinarios;

import java.util.Scanner;
import java.io.*;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

/*


Luego leerlos y mostrarlos para indicar los numeros pares e impares  

        //guardará los pares e impares
        int[] pares = new int[0], impares = new int[0];
        
        Scanner teclado = new Scanner(System.in);

        int n;

        //escritura
        try (ObjectOutputStream flujoSalida = new ObjectOutputStream(new FileOutputStream("numeros.dat"))) {
            for (int i = 0; i < 2; i++) { //CAMBIAR CUANDO TERMINE
                System.out.println("Indica el número: ");
                n = teclado.nextInt();
                flujoSalida.writeInt(n);
            }

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        try (ObjectInputStream flujoEntrada = new ObjectInputStream(new FileInputStream("numeros.dat"))) {
            //array para guardar los valores de entero
            int i = 0;
            while (true) {
                int aux = flujoEntrada.readInt();
                System.out.println(aux);

                if (aux % 2 == 0) {
                    pares = Arrays.copyOf(pares, pares.length + 1);
                    pares[pares.length - 1] = aux;
                    i++;

                } else {
                    impares = Arrays.copyOf(impares, impares.length + 1);
                    impares[impares.length - 1] = aux;
                    i++;

                }
            }

        } catch (EOFException x) {
            System.out.println("");
        } catch (FileNotFoundException ex) {
            System.out.println("Fichero no encontrado");
        } catch (IOException ex) {
            System.out.println(ex);
        }
        
        System.out.println("Pares " + Arrays.toString(pares));
        System.out.println("Impares " + Arrays.toString(impares));
        
        //guardamos los pares e impares 
        try (ObjectOutputStream flujoSalida = new ObjectOutputStream(new FileOutputStream("pares.dat"))) {
            
        } catch (Exception e) {
        }

 */
public class ParesImparesLecturaEscrituraBinarios {

    /*
   solicitar al usuario 10 enteros y se guarda en un fichero 
binario numeros.dat (uno a uno). 
Luegos se hace la lectrua del fichero entero a entero 
y vamos a guardar los numero pares en un fichero pares.dat 
y los impares en impares.dat.  
     */
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        int[] pares = new int[0];
        int[] impares = new int[0];

        try (ObjectOutputStream flujoSalida1 = new ObjectOutputStream(new FileOutputStream("numeros.dat"))) {

            for (int i = 0; i < 10; i++) {
                System.out.println("Ingrese el número: ");
                int v = teclado.nextInt();

                flujoSalida1.writeInt(v);

                flujoSalida1.flush();
            }

        } catch (IOException e) {
            System.out.println("Fichero no encontrado");
        }

        //lee y escribo en pares e impares
        try (ObjectInputStream flujoEntrada = new ObjectInputStream(new FileInputStream("numeros.dat")); 
             ObjectOutputStream flujoSalida1 = new ObjectOutputStream(new FileOutputStream("pares.dat")); 
             ObjectOutputStream flujoSalida2 = new ObjectOutputStream(new FileOutputStream("impares.dat"))) {

            while (true) {
                //leemos y mostramos
                int n = flujoEntrada.readInt();

                //System.out.println("Numero " + n );
                if (n % 2 == 0) {
                    flujoSalida1.writeInt(n);
                } else {
                    flujoSalida2.writeInt(n);
                }

            }

        } catch (EOFException e) {
            System.out.println("");

        } catch (FileNotFoundException ex) {
            System.out.println("Fichero no encontrado");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        //mostramos pares e impares
        try (ObjectInputStream flujoEntrada = new ObjectInputStream(new FileInputStream("pares.dat")); ObjectInputStream flujoEntrada2 = new ObjectInputStream(new FileInputStream("impares.dat"))) {

            while (true) {
                int nP = flujoEntrada.readInt();
                int nImPar = flujoEntrada2.readInt();

                System.out.println("Numero par " + nP);

                System.out.println("Numero impar " + nImPar);

            }

        } catch (EOFException e) {
            System.out.println("final fichero");

        } catch (FileNotFoundException ex) {
            System.out.println("Fichero no encontrado");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

}
