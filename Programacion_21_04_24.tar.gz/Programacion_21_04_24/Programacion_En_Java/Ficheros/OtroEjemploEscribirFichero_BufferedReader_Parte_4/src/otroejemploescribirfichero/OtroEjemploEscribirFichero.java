/*
Escribir algo en un archivo y mostrarlo tanto en la 
misma carpeta y en otra ruta
 */
package otroejemploescribirfichero;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class OtroEjemploEscribirFichero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        try {
            //FileReader fr = new FileReader("Saludo.txt"); //este funciona
            FileReader fr = new FileReader("/home/alumnado/Escritorio");

            //esto es mas eficiente
            //BufferedReader inBuffer= new BufferedReader(fr);
            //int c= inBuffer.read();
            int i;

            while ((i = fr.read()) != -1) {
                System.out.println((char) i);
            }

            //
        } catch (FileNotFoundException ex) {
            System.out.println("Error: fichero no encotrado.");
        } catch (IOException ex) {
            System.out.println("Error de lectura");
        }

    }
}
