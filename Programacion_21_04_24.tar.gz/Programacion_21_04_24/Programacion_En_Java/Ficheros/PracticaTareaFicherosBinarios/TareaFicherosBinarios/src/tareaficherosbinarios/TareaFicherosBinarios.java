/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tareaficherosbinarios;

/**
 *
 * @author martarobina
 */

/*Implementa
una aplicación que gestione una lista de nombres ordenada por orden
alfabético. Al arrancar, se leerá de un fichero los nombres insertados
anteriormente, mostrando "Lista vacía" en caso de que el fichero esté
vacío o mostrando la lista de nombres en caso de que hubiera datos. A
continuación, se pedirá al usuario nombres nuevos hasta que introduzca
la cadena "fin". Cada nombre que se introduzca deberá añadirse a los que
ya había, de forma que la lista permanezca ordenada. Al terminar, si
hay nombres en la lista, se guardará en el fichero la lista actualizada.*/

import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

public class TareaFicherosBinarios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    String[] listaNombres = new String[0];
    
    
        /*Lectura de la lista de nombres grabados anteriormente*/
        try ( ObjectInputStream in = new ObjectInputStream(
                new FileInputStream("lista.dat"))) {
            listaNombres = (String[]) in.readObject();
            System.out.println("Lista de nombres: ");
            System.out.println(Arrays.toString(listaNombres));
        } catch (IOException ex) {
            System.out.println("lista vacía");
        } catch (ClassNotFoundException ex) {
            System.out.println(ex);
        }
        
        /*Introducción de nombres nuevos en la lista*/
        System.out.print("Introducir nombre: ");
        String nuevo = new Scanner(System.in).nextLine();
        while (!nuevo.equals("fin")) {
            listaNombres = Arrays.copyOf(listaNombres,
                    listaNombres.length + 1);
            listaNombres[listaNombres.length - 1] = nuevo;
            Arrays.sort(listaNombres);
            System.out.print("Introducir nombre: ");
            nuevo = new Scanner(System.in).nextLine();
        }
        
        /*Guardado de la lista en el fichero binario*/
        if (listaNombres.length > 0) {//si la lista no está vacía
            try ( ObjectOutputStream out = new ObjectOutputStream(
                    new FileOutputStream("lista.dat"))) {
                out.writeObject(listaNombres);
            } catch (IOException ex) {
                System.out.println(ex);
            }
        }
    }
    
}
