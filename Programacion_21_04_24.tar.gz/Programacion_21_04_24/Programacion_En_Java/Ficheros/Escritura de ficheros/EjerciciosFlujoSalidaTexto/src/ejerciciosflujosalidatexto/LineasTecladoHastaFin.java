/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosflujosalidatexto;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author martarobina
 */
public class LineasTecladoHastaFin {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try (BufferedWriter out = new BufferedWriter(new FileWriter("Salida.txt"))) {
            String linea = sc.nextLine();
            while (!linea.equals("fin")) {
                out.write(linea);
                out.newLine();
                linea = sc.nextLine();
            }
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }
}
