/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosrepasoficherostexto;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author martarobina
 */
public class NombreEdad {

    public static void main(String[] args) {
        System.out.print("Nombre: ");
        String nombre = new Scanner(System.in).nextLine();
        System.out.print("Edad: ");
        int edad = new Scanner(System.in).nextInt();
        try (BufferedWriter salida = new BufferedWriter(
                new FileWriter("datos.txt", true))) {
            salida.write(nombre + "\t" + edad);
            salida.newLine();
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }
}
