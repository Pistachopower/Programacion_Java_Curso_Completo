/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejerciciosrepasoficherostexto;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author martarobina
 */
public class PedirNombreFichMostrarContenido {

    /**
     escribir un programa en java que pida el nombre del fichero y lo cree. En caso 
     de que el fichero no exista debe crearse con prueba.txt
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.print("Introducir nombre de fichero: ");
        String nombreFichero = new Scanner(System.in).nextLine();
        if (nombreFichero.equals("")) {
            nombreFichero = "prueba.txt";
        }
        try ( BufferedReader entrada = 
                new BufferedReader(new FileReader(nombreFichero))) {
            String linea=entrada.readLine();
            while(linea!=null){
                System.out.println(linea);
                linea=entrada.readLine();
            }
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }
    
}
