
package practica;

import java.util.Scanner;

/*
8.- Diseña un programa Java que calcule la suma y resta de dos números introducidos
por teclado. A continuación, la multiplicación y división de otros dos números
introducidos por teclado. Después, debes incorporar las funciones que permitan realizar
la potencia del primer número y la raíz cuadrada del cuarto. Salida del programa para
los números a=7, b=3, c=4, d=9:
Introducir primer número: a= 7
Introducir segundo número: b= 3
a = 7.0 b = 3.0
a + b = 10.0
a - b = 4.0
Introducir tercer número: c= 18

Introducir cuarto número: d=9
c * d = 162.0
c / d = 2.0
a ^ 2 = 49.0
√ d = 3.0
*/

public class Operaciones_Aritmeticas {
    public static void main(String[] args) {
        Scanner teclado= new Scanner(System.in);
        double a,b,c,d;
        
        System.out.println("Introduce los valores de A y B: ");
        a= teclado.nextDouble(); //7
        b= teclado.nextDouble(); //3
       
        System.out.println("suma: " + (a + b)); //10.0
        System.out.println("resta: " + (a - b)); //4.0
        
        System.out.println("Introduce los valores de C y D");
        c= teclado.nextDouble(); //18
        d= teclado.nextDouble(); //9
        
        System.out.println("multiplicacion: " + (c * d)); //162.0
        System.out.println("division: " + (c / d)); //2.0
        System.out.println("Potencia: "+ (Math.pow(a, 2))); //49.0
        System.out.println("raiz cuadrada: "+ (Math.sqrt(d))); //3.0
    }
}
