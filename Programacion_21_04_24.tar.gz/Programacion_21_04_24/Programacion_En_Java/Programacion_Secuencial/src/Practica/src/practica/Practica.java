
package practica;

public class Practica {

    public enum  Productos {tornillo, martillo, tuerca, chincheta};
    
    public static void main(String[] args) {
        Productos m= Productos.martillo;
        Productos m_1= Productos.tuerca;
        
        System.out.println(m);
        System.out.println(m_1);
        
    }
    
}
