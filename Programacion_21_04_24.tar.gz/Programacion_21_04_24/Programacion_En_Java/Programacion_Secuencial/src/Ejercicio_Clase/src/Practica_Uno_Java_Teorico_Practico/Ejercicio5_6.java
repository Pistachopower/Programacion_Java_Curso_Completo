
package Practica_Uno_Java_Teorico_Practico;

import java.util.Scanner;


public class Ejercicio5_6 {


    public enum Productos {
        tornillo, martillo, tuerca, chincheta
    }; //declaramos el tipo enumerado para el ejercicio 6
    
    public static void main(String[] args) {

        
        //Ejercicio5
        
        int num1, num2, multi; //Variables ejercicio5
        Productos m; //Declaramos la variable del ejercicio 6
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Introduce un numero");
        num1=teclado.nextInt();
        
        System.out.println("Introduce otro numero");
        num2=teclado.nextInt();
        
        String igualDistinto=(num1==num2)?"son iguales":"son distintos";
        System.out.println("Los numeros dados "+igualDistinto);
        
        multi = num1 * num2;
        System.out.println("Los numeros multiplicados entre ellos dan "+multi);   
       
        //Ejercicio6

        m=Productos.martillo;   
        System.out.println("El valor de m es "+m);
        
        m= Productos.tuerca;
        System.out.println("El valor de m es "+m);
        
        }
    }
    

