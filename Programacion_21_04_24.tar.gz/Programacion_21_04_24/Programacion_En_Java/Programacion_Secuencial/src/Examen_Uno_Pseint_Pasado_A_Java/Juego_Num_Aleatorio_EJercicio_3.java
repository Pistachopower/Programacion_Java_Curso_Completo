package Examen_Uno_Pseint_Pasado_A_Java;

import java.util.Scanner;

public class Juego_Num_Aleatorio_EJercicio_3 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int num_Aleatorio = (int) (Math.random() * 100 + 1);

        boolean interruptor = false;
        int contador = 0;
        int valor_Usuario;

        System.out.println("NUMERO ALEATORIO " + num_Aleatorio);

        while ((contador < 10) && (interruptor == false)) {
            System.out.println("Introduce el número aleatorio: ");
            valor_Usuario = teclado.nextInt();

            while (valor_Usuario <= 0 || valor_Usuario >100) {
                System.out.println("Disculpe, el número debe ser mayor a 0 y menor que 100");
                System.out.println("¿Introduce el número aleatorio: : ");
                valor_Usuario = teclado.nextInt();
            }

            if (valor_Usuario > num_Aleatorio) {
                System.out.println(valor_Usuario + " es mayor que el número aleatorio");
            }
            if (valor_Usuario < num_Aleatorio) {
                System.out.println(valor_Usuario + " es menor que el número aleatorio");
            }

            if (valor_Usuario == num_Aleatorio) {
                interruptor = true;
            }

            contador++;
        }

        if (interruptor == true) {
            System.out.println("Has adivinado el número aleatorio que era: " + num_Aleatorio);
        } else {
            System.out.println("Has agotado tus intentos. ");
        }

    }
}
