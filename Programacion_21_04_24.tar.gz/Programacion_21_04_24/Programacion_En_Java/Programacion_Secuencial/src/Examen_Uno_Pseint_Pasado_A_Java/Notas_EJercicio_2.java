package Examen_Uno_Pseint_Pasado_A_Java;
/*
Deficientes 0-3
Regulares 4-5
Buenos 6-8
Excelentes 9-10
*/

import java.util.Scanner;

public class Notas_EJercicio_2 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int notas;
        int aleatorio;
        int deficientes=0;
        int regulares= 0;
        int buenos=0;
        int excelentes=0;
        
        System.out.println("¿Introduce la nota: ");
        notas = teclado.nextInt();

        for (int i = 1; i <= notas; i++) {
            aleatorio = (int) (Math.random()*10+1);  
            
            if (aleatorio >= 0 && aleatorio <= 3 ) {
                deficientes++;
            }
            if (aleatorio >= 4 && aleatorio <= 5 ) {
                regulares++;
            }
            if (aleatorio >= 6 && aleatorio <= 8 ) {
                buenos++;
            }
            if (aleatorio >= 9 && aleatorio <= 10 ) {
                excelentes++;
            }
        }
        
        System.out.println("deficiente " + deficientes);
        System.out.println("regulares " + regulares);
        System.out.println("Buenos " + buenos);
        System.out.println("Excelente " + excelentes);

    }
}
