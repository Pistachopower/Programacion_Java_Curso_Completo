/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modular;

import java.util.Scanner;

/**
ana ejemplo palindromo
 */
public class palindromo {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String palabra;
        System.out.println("introduce palabra: ");
        palabra= teclado.nextLine();
        
        // Inicializamos la cadena invertida como una cadena vacía
        String palabraInvertida = "";

// Recorremos la cadena original carácter a carácter
        for (int i = 0; i < palabra.length(); i++) {
            // Concatenamos cada carácter al principio de la cadena invertida
            palabraInvertida = palabra.charAt(i) + palabraInvertida;
        }

// Convertimos ambas cadenas a mayúsculas para ignorar las diferencias entre mayúsculas y minúsculas
        palabra = palabra.toUpperCase();
        palabraInvertida = palabraInvertida.toUpperCase();

// Comparamos la cadena original y la cadena invertida
// Si son iguales, entonces la palabra es un palíndromo
        boolean esPalindromo = palabra.equals(palabraInvertida);
        
        System.out.println(esPalindromo);
                

    }
}
