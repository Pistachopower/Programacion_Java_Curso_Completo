package EjercicioVariable;

import java.util.Scanner;

public class Apartado_Cinco {

    public static void main(String[] args) {
        /*
        5.- Diseña un programa Java que pida dos números por teclado, escriba en pantalla si
        son iguales o distintos y además muestre el resultado de multiplicarlos.

        */
        // Crear un objeto Scanner para leer la entrada del usuario
        Scanner teclado = new Scanner(System.in);

        // Pide al usuario que ingrese el primer número
        System.out.print("Ingrese el primer número: ");
        int numero1 = teclado.nextInt();

        // Pedir al usuario que ingrese el segundo número
        System.out.print("Ingrese el segundo número: ");
        int numero2 = teclado.nextInt();

        // Comparar si los números son iguales o distintos
        if (numero1 == numero2) {
            System.out.println("Los números son iguales.");
        } else {
            System.out.println("Los números son distintos.");
        }

        // Calculamos y mostramos el resultado de la multiplicación
        int resultadoMultiplicacion = numero1 * numero2;
        System.out.println("El resultado de la multiplicación es: " + resultadoMultiplicacion);

        // Cerraramos el Scanner por temas de memoria
        teclado.close();
    }
}
